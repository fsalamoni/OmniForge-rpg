import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import NpcCard from '../components/campaign-view/NpcCard';
import GenerateNpcDialog from '../components/campaign-view/GenerateNpcDialog';
import EditableSection from '../components/campaign-view/EditableSection';
import EncounterCard from '../components/campaign-view/EncounterCard';
import PlotHooksList from '../components/campaign-view/PlotHooksList';
import HooksView from '../components/campaign-view/HooksView';
import ArcsView from '../components/campaign-view/ArcsView';
import HooksGenerator from '../components/campaign-view/HooksGenerator';
import ArcGenerator from '../components/campaign-view/ArcGenerator';
import NpcSelector from '../components/campaign-view/NpcSelector';
import WbsView from '../components/campaign-management/WbsView';
import SwotView from '../components/campaign-management/SwotView';
import StakeholdersMatrix from '../components/campaign-management/StakeholdersMatrix';
import DecisionFlowView from '../components/campaign-management/DecisionFlowView';
import CampaignMap from '../components/campaign-management/CampaignMap';
import SessionTracker from '../components/campaign-progression/SessionTracker';
import WorldStateDashboard from '../components/campaign-progression/WorldStateDashboard';
import RewardsDashboard from '../components/campaign-progression/RewardsDashboard';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import ReactMarkdown from 'react-markdown';
import { 
  ArrowLeft, 
  BookOpen, 
  Users, 
  StickyNote,
  Settings,
  Globe,
  Lock,
  Loader2,
  Share2,
  Sparkles,
  Filter,
  LayoutDashboard,
  TrendingUp,
  Anchor,
  FileText
} from 'lucide-react';

export default function CampaignView() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const campaignId = searchParams.get('id');
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [masterNotes, setMasterNotes] = useState('');
  const [notesChanged, setNotesChanged] = useState(false);
  const [npcFilter, setNpcFilter] = useState('all');
  const [powerFilter, setPowerFilter] = useState('all');
  const [interestFilter, setInterestFilter] = useState('all');
  const [archetypeFilter, setArchetypeFilter] = useState('all');
  const [connectionFilter, setConnectionFilter] = useState('');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        await base44.auth.redirectToLogin(createPageUrl('CampaignView') + '?id=' + campaignId);
      }
    };
    loadUser();
  }, []);

  const { data: campaign, isLoading, refetch } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: async () => {
      console.log('📥 Buscando campanha do banco...');
      const campaigns = await base44.entities.Campaign.list();
      const camp = campaigns.find(c => c.id === campaignId);
      if (camp) {
        setMasterNotes(camp.master_notes || '');
        console.log('📊 Campanha carregada:', {
          id: camp.id,
          arcos: camp.content_json?.narrative_arcs?.length || 0,
          arcosNomes: camp.content_json?.narrative_arcs?.map(a => a.name) || []
        });
      }
      return camp;
    },
    enabled: !!campaignId,
    refetchOnWindowFocus: false,
    refetchOnMount: true,
    staleTime: 0,
    gcTime: 0
  });

  const { data: npcs = [] } = useQuery({
    queryKey: ['npcs', campaignId],
    queryFn: () => base44.entities.NpcCreature.filter({ campaign_id: campaignId }),
    enabled: !!campaignId
  });

  const updateNotesMutation = useMutation({
    mutationFn: () => base44.entities.Campaign.update(campaignId, { master_notes: masterNotes }),
    onSuccess: () => {
      queryClient.invalidateQueries(['campaign', campaignId]);
      setNotesChanged(false);
    }
  });

  const togglePublicMutation = useMutation({
    mutationFn: () => base44.entities.Campaign.update(campaignId, { is_public: !campaign.is_public }),
    onSuccess: () => {
      queryClient.invalidateQueries(['campaign', campaignId]);
    }
  });

  const updateContentMutation = useMutation({
    mutationFn: (newContent) => base44.entities.Campaign.update(campaignId, { content_json: newContent }),
    onSuccess: async () => {
      await queryClient.invalidateQueries(['campaign', campaignId]);
      await refetch();
    }
  });

  const handleHooksGenerated = async (newHooks) => {
    const currentContent = campaign?.content_json || {};
    const updatedContent = {
      ...currentContent,
      plot_hooks: [...(currentContent.plot_hooks || []), ...newHooks]
    };
    await updateContentMutation.mutateAsync(updatedContent);
  };

  const handleArcGenerated = async (newArc) => {
    try {
      console.log('🎬 SALVANDO ARCO NO BANCO DE DADOS');
      
      if (!newArc?.name || !Array.isArray(newArc.acts) || newArc.acts.length === 0) {
        throw new Error('Arco inválido');
      }
      
      const arcWithCompletion = {
        ...newArc,
        acts: newArc.acts.map(act => ({
          ...act,
          completed: false,
          scenes: (act.scenes || []).map(scene => ({ ...scene, completed: false }))
        }))
      };
      
      // Buscar dados mais recentes diretamente do banco
      const allCampaigns = await base44.entities.Campaign.list();
      const currentCampaign = allCampaigns.find(c => c.id === campaignId);
      
      if (!currentCampaign) throw new Error('Campanha não encontrada no banco de dados');
      
      const existingArcs = Array.isArray(currentCampaign.content_json?.narrative_arcs) 
        ? currentCampaign.content_json.narrative_arcs 
        : [];
      
      const updatedContentJson = {
        ...currentCampaign.content_json,
        narrative_arcs: [...existingArcs, arcWithCompletion]
      };
      
      console.log('💾 SALVANDO:', {
        arcosAntes: existingArcs.length,
        arcosDepois: updatedContentJson.narrative_arcs.length,
        nomeNovoArco: arcWithCompletion.name
      });
      
      // SALVAR NO BANCO
      await base44.entities.Campaign.update(campaignId, { 
        content_json: updatedContentJson 
      });
      
      console.log('✅ SALVO NO BANCO COM SUCESSO!');
      
      // Aguardar propagação no banco
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Buscar dados atualizados diretamente do banco para confirmar
      const verificationCampaigns = await base44.entities.Campaign.list();
      const verifiedCampaign = verificationCampaigns.find(c => c.id === campaignId);
      
      console.log('🔍 VERIFICAÇÃO PÓS-SAVE:', {
        arcosSalvosNoBanco: verifiedCampaign?.content_json?.narrative_arcs?.length || 0,
        nomesDosSalvos: verifiedCampaign?.content_json?.narrative_arcs?.map(a => a.name) || []
      });
      
      // Limpar cache React Query completamente
      queryClient.removeQueries(['campaign', campaignId]);
      queryClient.invalidateQueries(['campaign', campaignId]);
      
      // Forçar refetch com dados frescos
      await refetch();
      
      const totalScenes = arcWithCompletion.acts.reduce((sum, act) => sum + (act.scenes?.length || 0), 0);
      alert(`✅ Arco "${arcWithCompletion.name}" salvo no banco!\n\n${arcWithCompletion.acts.length} atos • ${totalScenes} cenas\n\nREFRESH: Os dados foram recarregados.`);
      
    } catch (error) {
      console.error('❌ ERRO CRÍTICO AO SALVAR:', error);
      alert('ERRO ao salvar arco: ' + error.message);
    }
  };

  const handleUpdateDescription = async (newDescription) => {
    const currentContent = campaign?.content_json || {};
    const updatedContent = { ...currentContent, campaign_description: newDescription };
    await updateContentMutation.mutateAsync(updatedContent);
  };

  if (!campaignId) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400">ID de campanha não fornecido</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="text-center py-16">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
        <p className="text-slate-400">Carregando campanha...</p>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400 mb-4">Campanha não encontrada</p>
        <Button onClick={() => navigate(createPageUrl('MyCampaigns'))}>
          Voltar para Minhas Campanhas
        </Button>
      </div>
    );
  }

  const content = campaign.content_json || {};
  const isOwner = campaign.created_by === user?.email;

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <button
          onClick={() => navigate(createPageUrl('MyCampaigns'))}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar para Campanhas
        </button>

        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <Sparkles className="w-8 h-8 text-purple-400" />
              <h1 className="text-4xl font-bold text-white">
                {campaign.title}
              </h1>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="px-3 py-1 bg-purple-600/20 text-purple-300 text-sm font-medium rounded-lg border border-purple-500/30">
                {campaign.system_rpg}
              </span>
              <span className="px-3 py-1 bg-amber-600/20 text-amber-300 text-sm font-medium rounded-lg border border-amber-500/30">
                {campaign.setting}
              </span>
              <span className="px-3 py-1 bg-blue-600/20 text-blue-300 text-sm font-medium rounded-lg border border-blue-500/30">
                {campaign.duration_type}
              </span>
              <span className="px-3 py-1 bg-slate-600/20 text-slate-300 text-sm font-medium rounded-lg border border-slate-500/30">
                {campaign.players_count} jogadores
              </span>
            </div>

            <p className="text-slate-400">
              Nível de criatividade: <span className="text-purple-400 font-semibold">{campaign.creativity_level}/5</span>
            </p>
          </div>

          {isOwner && (
            <div className="flex gap-3">
              <Button
                onClick={() => navigate(createPageUrl('Generator') + '?id=' + campaign.id)}
                variant="outline"
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Editar Informações
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="description" className="space-y-6">
        <TabsList className="bg-slate-900/50 border border-purple-900/20 p-1 flex-wrap h-auto">
          <TabsTrigger value="description" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <FileText className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Descrição Geral</span>
            <span className="sm:hidden">Descrição</span>
          </TabsTrigger>
          <TabsTrigger value="hooks" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <Anchor className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Ganchos
          </TabsTrigger>
          <TabsTrigger value="arcs" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <BookOpen className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Arcos
          </TabsTrigger>
          <TabsTrigger value="npcs" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">NPCs e Monstros</span>
            <span className="sm:hidden">NPCs</span>
          </TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <StickyNote className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Notas
          </TabsTrigger>
          <TabsTrigger value="progression" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Progressão
          </TabsTrigger>
          <TabsTrigger value="management" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <LayoutDashboard className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Gestão
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300 text-xs sm:text-sm">
            <Settings className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Config
          </TabsTrigger>
        </TabsList>

        {/* Tab: Descrição Geral */}
        <TabsContent value="description" className="space-y-6">
          {(content.campaign_description || content.adventure_summary) && isOwner && (
            <EditableSection
              title="Descrição Geral da Campanha"
              content={content.campaign_description || content.adventure_summary}
              onSave={handleUpdateDescription}
              icon={FileText}
            />
          )}

          {(content.campaign_description || content.adventure_summary) && !isOwner && (
            <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <FileText className="w-6 h-6 text-purple-400" />
                Descrição Geral da Campanha
              </h2>
              <div className="text-slate-300 leading-relaxed prose prose-invert prose-slate max-w-none w-full overflow-visible">
                <ReactMarkdown
                  components={{
                    h1: ({ children }) => <h1 className="text-3xl font-bold text-white mt-8 mb-4 break-words">{children}</h1>,
                    h2: ({ children }) => <h2 className="text-2xl font-bold text-purple-300 mt-6 mb-3 break-words">{children}</h2>,
                    h3: ({ children }) => <h3 className="text-xl font-semibold text-purple-200 mt-4 mb-2 break-words">{children}</h3>,
                    p: ({ children }) => <p className="text-slate-300 text-base leading-relaxed mb-4 break-words">{children}</p>,
                    strong: ({ children }) => <strong className="font-bold text-white">{children}</strong>,
                    ul: ({ children }) => <ul className="list-disc list-inside text-slate-300 mb-4 space-y-2">{children}</ul>,
                    ol: ({ children }) => <ol className="list-decimal list-inside text-slate-300 mb-4 space-y-2">{children}</ol>,
                    li: ({ children }) => <li className="text-slate-300 leading-relaxed break-words">{children}</li>,
                    hr: () => <hr className="border-slate-700 my-6" />,
                  }}
                >
                  {content.campaign_description || content.adventure_summary}
                </ReactMarkdown>
              </div>
            </div>
          )}

          {!content.campaign_description && !content.adventure_summary && (
            <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
              <FileText className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">Descrição da campanha não disponível</p>
            </div>
          )}
        </TabsContent>

        {/* Tab: Ganchos */}
        <TabsContent value="hooks">
          <div className="space-y-8">
            {isOwner && (
              <HooksGenerator
                campaignId={campaignId}
                description={content.campaign_description || content.adventure_summary || ''}
                answers5W2H={campaign.answers_5w2h || ''}
                systemRpg={campaign.system_rpg}
                setting={campaign.setting}
                onHooksGenerated={handleHooksGenerated}
              />
            )}
            {content.plot_hooks && content.plot_hooks.length > 0 && (
              <div className="border-t border-slate-800 pt-8">
                <HooksView 
                  hooks={content.plot_hooks}
                  campaignContext={`Sistema: ${campaign.system_rpg}, Ambientação: ${campaign.setting}`}
                  systemRpg={campaign.system_rpg}
                />
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab: Arcos */}
        <TabsContent value="arcs">
          <div className="space-y-8">
            {isOwner && (
              <ArcGenerator
                campaignId={campaignId}
                description={content.campaign_description || content.adventure_summary || ''}
                answers5W2H={campaign.answers_5w2h || ''}
                systemRpg={campaign.system_rpg}
                setting={campaign.setting}
                onArcGenerated={handleArcGenerated}
              />
            )}

            {/* Sempre mostrar a seção de arcos */}
            <div className="border-t border-slate-800 pt-8">
              {campaign?.content_json?.narrative_arcs && campaign.content_json.narrative_arcs.length > 0 ? (
                <ArcsView 
                  arcs={campaign.content_json.narrative_arcs} 
                  campaignContext={`Sistema: ${campaign.system_rpg}, Ambientação: ${campaign.setting}`}
                  systemRpg={campaign.system_rpg}
                  gateways={campaign.content_json.decision_gateways || []}
                  campaignId={campaignId}
                  campaign={campaign}
                  isOwner={isOwner}
                />
              ) : (
                <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
                  <BookOpen className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg font-semibold">Nenhum arco narrativo criado ainda</p>
                  <p className="text-slate-500 text-sm mt-2">Use o gerador acima para criar seu primeiro arco</p>
                  {campaign?.content_json && (
                    <p className="text-slate-600 text-xs mt-4">
                      Debug: {JSON.stringify(Object.keys(campaign.content_json))}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Tab: Progressão Narrativa */}
        <TabsContent value="progression">
          <div className="space-y-8">
            <WorldStateDashboard campaignId={campaignId} isOwner={isOwner} />
            <div className="border-t border-slate-800 pt-8">
              <SessionTracker campaignId={campaignId} isOwner={isOwner} />
            </div>
            <div className="border-t border-slate-800 pt-8">
              <RewardsDashboard campaignId={campaignId} isOwner={isOwner} />
            </div>
          </div>
        </TabsContent>

        {/* Tab: Gestão da Campanha */}
        <TabsContent value="management">
          <div className="space-y-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-white mb-2">
                🎯 Painel de Gestão Administrativa
              </h2>
              <p className="text-slate-400 text-lg">
                Ferramentas disponíveis desde a criação da campanha
              </p>
            </div>

            {/* WBS - Work Breakdown Structure */}
            <div>
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white mb-2">
                  📊 WBS - Estrutura Analítica da Campanha
                </h3>
                <p className="text-slate-400">
                  Decomposição hierárquica dos objetivos, arcos e cenas da campanha
                </p>
              </div>
              <WbsView wbs={content.wbs} isOwner={isOwner} campaignId={campaignId} />
            </div>

            {/* SWOT do Antagonista */}
            <div className="pt-8 border-t border-slate-800">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white mb-2">
                  ⚔️ Análise SWOT - Perfil Estratégico do Antagonista
                </h3>
                <p className="text-slate-400">
                  Forças, Fraquezas, Oportunidades e Ameaças do vilão principal
                </p>
              </div>
              <SwotView swot={content.antagonist_swot} isOwner={isOwner} campaignId={campaignId} />
            </div>

            {/* Matriz de Stakeholders */}
            <div className="pt-8 border-t border-slate-800">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white mb-2">
                  👥 Matriz de Stakeholders - Poder x Interesse
                </h3>
                <p className="text-slate-400">
                  Mapeamento estratégico dos NPCs e facções por influência e motivação
                </p>
              </div>
              <StakeholdersMatrix stakeholders={content.stakeholders} isOwner={isOwner} />
            </div>

            {/* Fluxogramas de Decisão */}
            <div className="pt-8 border-t border-slate-800">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white mb-2">
                  🔀 Fluxogramas de Decisão - Logic Gates
                </h3>
                <p className="text-slate-400">
                  Ramificações lógicas baseadas nas escolhas dos jogadores
                </p>
              </div>
              <DecisionFlowView gateways={content.decision_gateways} isOwner={isOwner} campaignId={campaignId} />
            </div>

            {/* Mapa da Campanha */}
            <div className="pt-8 border-t border-slate-800">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white mb-2">
                  🗺️ Mapa Interativo da Campanha
                </h3>
                <p className="text-slate-400">
                  Visualização geográfica de locais, cenas e stakeholders
                </p>
              </div>
              <CampaignMap 
                wbs={content.wbs} 
                stakeholders={content.stakeholders}
                isOwner={isOwner} 
              />
            </div>
          </div>
        </TabsContent>

        {/* Tab: NPCs */}
        <TabsContent value="npcs">
          <div className="space-y-6">
            {isOwner && (
              <NpcSelector
                campaignId={campaignId}
                description={content.campaign_description || content.adventure_summary || ''}
                hooks={content.plot_hooks || []}
                arcs={content.narrative_arcs || []}
                systemRpg={campaign.system_rpg}
                onNpcsCreated={() => queryClient.invalidateQueries(['npcs', campaignId])}
              />
            )}

            {npcs.length > 0 && (
              <div className="border-t border-slate-800 pt-8">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-1">
                      Personagens e Criaturas
                    </h2>
                    <span className="text-slate-400">
                      {npcs.filter(npc => {
                    const typeMatch = npcFilter === 'all' || npc.type === npcFilter;
                    const stats = npc.stats_json || {};
                    const powerMatch = powerFilter === 'all' || (
                      powerFilter === 'low' ? stats.power <= 3 :
                      powerFilter === 'medium' ? stats.power >= 4 && stats.power <= 7 :
                      powerFilter === 'high' ? stats.power >= 8 : true
                    );
                    const interestMatch = interestFilter === 'all' || (
                      interestFilter === 'negative' ? stats.interest < 0 :
                      interestFilter === 'neutral' ? stats.interest === 0 :
                      interestFilter === 'positive' ? stats.interest > 0 : true
                    );
                    const archetypeMatch = archetypeFilter === 'all' || stats.archetype === archetypeFilter;
                    const connectionMatch = !connectionFilter || (
                      npc.name?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.primary?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.conflict?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.resource_dependency?.toLowerCase().includes(connectionFilter.toLowerCase())
                    );
                    return typeMatch && powerMatch && interestMatch && archetypeMatch && connectionMatch;
                  }).length} {' '}
                  {npcs.filter(npc => {
                    const typeMatch = npcFilter === 'all' || npc.type === npcFilter;
                    const stats = npc.stats_json || {};
                    const powerMatch = powerFilter === 'all' || (
                      powerFilter === 'low' ? stats.power <= 3 :
                      powerFilter === 'medium' ? stats.power >= 4 && stats.power <= 7 :
                      powerFilter === 'high' ? stats.power >= 8 : true
                    );
                    const interestMatch = interestFilter === 'all' || (
                      interestFilter === 'negative' ? stats.interest < 0 :
                      interestFilter === 'neutral' ? stats.interest === 0 :
                      interestFilter === 'positive' ? stats.interest > 0 : true
                    );
                    const archetypeMatch = archetypeFilter === 'all' || stats.archetype === archetypeFilter;
                    const connectionMatch = !connectionFilter || (
                      npc.name?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.primary?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.conflict?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.resource_dependency?.toLowerCase().includes(connectionFilter.toLowerCase())
                    );
                    return typeMatch && powerMatch && interestMatch && archetypeMatch && connectionMatch;
                  }).length === 1 ? 'personagem' : 'personagens'}
                </span>
              </div>
              
              {isOwner && (
                <GenerateNpcDialog
                  campaignId={campaignId}
                  systemRpg={campaign.system_rpg}
                  setting={campaign.setting}
                  onNpcCreated={() => queryClient.invalidateQueries(['npcs', campaignId])}
                />
              )}
            </div>

            {/* Filtros Avançados */}
            <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl space-y-4">
              <div className="flex items-center gap-2 text-white font-semibold mb-2">
                <Filter className="w-5 h-5 text-purple-400" />
                Filtros Avançados
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div>
                  <Label className="text-slate-400 text-xs mb-1 block">Tipo</Label>
                  <Select value={npcFilter} onValueChange={setNpcFilter}>
                    <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="NPC">NPCs</SelectItem>
                      <SelectItem value="Ally">Aliados</SelectItem>
                      <SelectItem value="Villain">Vilões</SelectItem>
                      <SelectItem value="Monster">Monstros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-1 block">Poder</Label>
                  <Select value={powerFilter} onValueChange={setPowerFilter}>
                    <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="low">Baixo (1-3)</SelectItem>
                      <SelectItem value="medium">Médio (4-7)</SelectItem>
                      <SelectItem value="high">Alto (8-10)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-1 block">Interesse</Label>
                  <Select value={interestFilter} onValueChange={setInterestFilter}>
                    <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="negative">Negativo</SelectItem>
                      <SelectItem value="neutral">Neutro</SelectItem>
                      <SelectItem value="positive">Positivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-1 block">Arquétipo</Label>
                  <Select value={archetypeFilter} onValueChange={setArchetypeFilter}>
                    <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="Facilitador">Facilitador</SelectItem>
                      <SelectItem value="Obstrutor">Obstrutor</SelectItem>
                      <SelectItem value="Oportunista">Oportunista</SelectItem>
                      <SelectItem value="Recurso Chave">Recurso Chave</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-1 block">Buscar Conexão</Label>
                  <Input
                    placeholder="Nome do NPC..."
                    value={connectionFilter}
                    onChange={(e) => setConnectionFilter(e.target.value)}
                    className="bg-slate-950/50 border-slate-700 text-white"
                  />
                </div>
              </div>

              {(npcFilter !== 'all' || powerFilter !== 'all' || interestFilter !== 'all' || archetypeFilter !== 'all' || connectionFilter) && (
                <Button
                  onClick={() => {
                    setNpcFilter('all');
                    setPowerFilter('all');
                    setInterestFilter('all');
                    setArchetypeFilter('all');
                    setConnectionFilter('');
                  }}
                  variant="outline"
                  className="border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  Limpar Filtros
                </Button>
              )}
            </div>

            {npcs.length === 0 ? (
              <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
                <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">Nenhum NPC ou criatura gerado ainda</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {npcs
                  .filter(npc => {
                    const typeMatch = npcFilter === 'all' || npc.type === npcFilter;
                    const stats = npc.stats_json || {};
                    const powerMatch = powerFilter === 'all' || (
                      powerFilter === 'low' ? stats.power <= 3 :
                      powerFilter === 'medium' ? stats.power >= 4 && stats.power <= 7 :
                      powerFilter === 'high' ? stats.power >= 8 : true
                    );
                    const interestMatch = interestFilter === 'all' || (
                      interestFilter === 'negative' ? stats.interest < 0 :
                      interestFilter === 'neutral' ? stats.interest === 0 :
                      interestFilter === 'positive' ? stats.interest > 0 : true
                    );
                    const archetypeMatch = archetypeFilter === 'all' || stats.archetype === archetypeFilter;
                    const connectionMatch = !connectionFilter || (
                      npc.name?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.primary?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.conflict?.toLowerCase().includes(connectionFilter.toLowerCase()) ||
                      stats.connections?.resource_dependency?.toLowerCase().includes(connectionFilter.toLowerCase())
                    );
                    return typeMatch && powerMatch && interestMatch && archetypeMatch && connectionMatch;
                  })
                  .map((npc) => (
                    <NpcCard 
                      key={npc.id} 
                      npc={npc}
                      isOwner={isOwner}
                      campaignId={campaignId}
                      onUpdate={() => queryClient.invalidateQueries(['npcs', campaignId])}
                    />
                  ))}
                  </div>
                  )}
                  </div>
                  )}
                  </div>
                  </TabsContent>

                  {/* Tab: Notas do Mestre */}
        <TabsContent value="notes">
          <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl">
            <h2 className="text-2xl font-bold text-white mb-4">
              Notas do Mestre
            </h2>
            <p className="text-slate-400 mb-4">
              Use este espaço para adicionar suas próprias anotações, ideias e modificações.
            </p>
            
            <Textarea
              value={masterNotes}
              onChange={(e) => {
                setMasterNotes(e.target.value);
                setNotesChanged(true);
              }}
              placeholder="Adicione suas notas aqui..."
              className="min-h-[300px] bg-slate-950/50 border-slate-700 text-white"
              disabled={!isOwner}
            />

            {isOwner && notesChanged && (
              <div className="flex justify-end mt-4">
                <Button
                  onClick={() => updateNotesMutation.mutate()}
                  disabled={updateNotesMutation.isLoading}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {updateNotesMutation.isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    'Salvar Notas'
                  )}
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab: Configurações */}
        <TabsContent value="settings">
          <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl space-y-6">
            <h2 className="text-2xl font-bold text-white mb-4">
              Configurações da Campanha
            </h2>

            {isOwner ? (
              <>
                {/* Visibilidade */}
                <div className="p-6 bg-slate-950/50 border border-slate-700 rounded-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {campaign.is_public ? (
                          <Globe className="w-5 h-5 text-green-400" />
                        ) : (
                          <Lock className="w-5 h-5 text-slate-500" />
                        )}
                        <h3 className="text-lg font-semibold text-white">
                          {campaign.is_public ? 'Campanha Pública' : 'Campanha Privada'}
                        </h3>
                      </div>
                      <p className="text-slate-400 text-sm">
                        {campaign.is_public 
                          ? 'Esta campanha está visível na biblioteca pública e pode ser clonada por outros usuários.'
                          : 'Esta campanha é privada e apenas você pode vê-la.'
                        }
                      </p>
                    </div>
                    <Button
                      onClick={() => togglePublicMutation.mutate()}
                      disabled={togglePublicMutation.isLoading}
                      variant="outline"
                      className={campaign.is_public 
                        ? 'border-red-900/50 text-red-400 hover:bg-red-900/20'
                        : 'border-green-900/50 text-green-400 hover:bg-green-900/20'
                      }
                    >
                      {togglePublicMutation.isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          {campaign.is_public ? 'Tornar Privada' : 'Tornar Pública'}
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {/* Estatísticas */}
                {campaign.is_public && campaign.clone_count > 0 && (
                  <div className="p-6 bg-purple-900/10 border border-purple-500/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Share2 className="w-5 h-5 text-purple-400" />
                      <h3 className="text-lg font-semibold text-white">
                        Estatísticas
                      </h3>
                    </div>
                    <p className="text-slate-300">
                      Esta campanha foi clonada <span className="text-purple-400 font-bold">{campaign.clone_count}</span> {campaign.clone_count === 1 ? 'vez' : 'vezes'}
                    </p>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-8 text-slate-400">
                Apenas o criador da campanha pode modificar configurações.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}