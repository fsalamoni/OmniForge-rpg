import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import QuestionCard from '../components/generator/QuestionCard';
import ProgressBar from '../components/generator/ProgressBar';
import { Wand2, ArrowLeft, Sparkles, Loader2 } from 'lucide-react';

const QUESTIONS_5W2H = [
  {
    key: 'what',
    title: 'O Quê? (What)',
    description: 'Qual é o conflito principal da aventura?',
    placeholder: 'Ex: Uma antiga relíquia foi roubada e ameaça despertar um mal ancestral...',
    examples: [
      'Um culto está tentando invocar um demônio',
      'A cidade está sendo atacada por criaturas desconhecidas',
      'Um artefato mágico está corrompendo a região'
    ]
  },
  {
    key: 'why',
    title: 'Por Quê? (Why)',
    description: 'Qual a motivação dos vilões ou do mundo?',
    placeholder: 'Ex: O vilão busca vingança contra aqueles que o traíram...',
    examples: [
      'Vingança pessoal contra uma organização',
      'Poder absoluto através de magia proibida',
      'Sobrevivência em um mundo hostil'
    ]
  },
  {
    key: 'where',
    title: 'Onde? (Where)',
    description: 'Onde a ação começa?',
    placeholder: 'Ex: Em uma pequena vila nas montanhas, cercada por florestas antigas...',
    examples: [
      'Uma metrópole cyberpunk cheia de neon',
      'Ruínas de uma civilização perdida',
      'Uma estação espacial isolada'
    ]
  },
  {
    key: 'when',
    title: 'Quando? (When)',
    description: 'Em que período/época dentro da ambientação?',
    placeholder: 'Ex: Durante um eclipse lunar, quando as barreiras entre mundos enfraquecem...',
    examples: [
      'No auge de uma guerra civil',
      'Cem anos após um apocalipse',
      'Durante um festival importante'
    ]
  },
  {
    key: 'who',
    title: 'Quem? (Who)',
    description: 'Quem são as figuras centrais (aliados/inimigos)?',
    placeholder: 'Ex: Um senhor da guerra corrupto, um sábio misterioso, uma ladina rebelde...',
    examples: [
      'Um mentor traidor, um aliado improvável',
      'Uma corporação corrupta e seus executores',
      'Um culto fanático liderado por um profeta'
    ]
  },
  {
    key: 'how',
    title: 'Como? (How)',
    description: 'Como os jogadores se envolveram?',
    placeholder: 'Ex: Foram contratados por um nobre desesperado...',
    examples: [
      'Testemunharam um crime e foram perseguidos',
      'Receberam uma mensagem de alguém próximo',
      'Estavam no lugar errado na hora errada'
    ]
  },
  {
    key: 'how_much',
    title: 'Quanto? (How Much)',
    description: 'Qual o nível de letalidade e complexidade esperada?',
    placeholder: 'Ex: Alta letalidade, conspiração complexa com múltiplas facções...',
    examples: [
      'Baixa letalidade, foco em investigação',
      'Alta intensidade, combates frequentes',
      'Média complexidade, mistério central'
    ]
  }
];

export default function Generator() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const campaignId = searchParams.get('id');

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [availableSystems, setAvailableSystems] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  
  const [formData, setFormData] = useState({
    title: '',
    system_rpg: 'D&D 5e',
    setting: 'Fantasia Medieval',
    duration_type: 'One-shot',
    players_count: 4
  });

  const [answers, setAnswers] = useState({});
  const [creativityLevel, setCreativityLevel] = useState(2);
  const [activeCampaignId, setActiveCampaignId] = useState(campaignId);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setIsAdmin(currentUser.role === 'admin');
      } catch (error) {
        await base44.auth.redirectToLogin(createPageUrl('Generator'));
      }
    };
    loadUser();
  }, []);

  useEffect(() => {
    const loadSystems = async () => {
      try {
        const systems = await base44.entities.RpgSystem.filter({ is_active: true });
        setAvailableSystems(systems);
      } catch (error) {
        console.error('Erro ao carregar sistemas:', error);
      }
    };
    loadSystems();
  }, []);

  useEffect(() => {
    if (campaignId && user) {
      loadExistingCampaign();
    }
  }, [campaignId, user]);

  const loadExistingCampaign = async () => {
    try {
      const campaigns = await base44.entities.Campaign.list();
      const campaign = campaigns.find(c => c.id === campaignId);
      
      if (campaign && campaign.created_by === user.email) {
        setFormData({
          title: campaign.title,
          system_rpg: campaign.system_rpg,
          setting: campaign.setting,
          duration_type: campaign.duration_type,
          players_count: campaign.players_count
        });
        setCreativityLevel(campaign.creativity_level);
        setCurrentStep(campaign.current_step);

        const steps = await base44.entities.CampaignStep.filter({ campaign_id: campaignId });
        const answersObj = {};
        steps.forEach(step => {
          answersObj[step.question_key] = step.user_answer;
        });
        setAnswers(answersObj);
      }
    } catch (error) {
      console.error('Erro ao carregar campanha:', error);
    }
  };

  const handleInitialSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (activeCampaignId) {
        await base44.entities.Campaign.update(activeCampaignId, {
          ...formData,
          current_step: 1
        });
      } else {
        const newCampaign = await base44.entities.Campaign.create({
          ...formData,
          current_step: 1,
          creativity_level: creativityLevel,
          is_completed: false,
          is_public: false
        });
        setActiveCampaignId(newCampaign.id);
      }
      
      setCurrentStep(1);
    } catch (error) {
      console.error('Erro ao criar campanha:', error);
      alert('Erro ao criar campanha. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleAIFullGeneration = async (e) => {
    e.preventDefault();
    setGenerating(true);

    try {
      let campaignIdToUse = activeCampaignId;
      
      if (!campaignIdToUse) {
        const newCampaign = await base44.entities.Campaign.create({
          ...formData,
          current_step: 1,
          creativity_level: creativityLevel,
          is_completed: false,
          is_public: false
        });
        campaignIdToUse = newCampaign.id;
        setActiveCampaignId(campaignIdToUse);
      }

      const aiPrompt = `Você é um especialista em criar campanhas de RPG. Com base nas informações abaixo, gere respostas COMPLETAS e DETALHADAS para as 7 perguntas do framework 5W2H.

Informações da Campanha:
- Título: ${formData.title}
- Sistema: ${formData.system_rpg}
- Ambientação: ${formData.setting}
- Duração: ${formData.duration_type}
- Jogadores: ${formData.players_count}

Gere respostas criativas, detalhadas e coerentes (mínimo 3-4 sentenças por resposta) para cada pergunta:

1. O QUÊ (What) - Qual é o conflito principal da aventura?
2. POR QUÊ (Why) - Qual a motivação dos vilões ou do mundo?
3. ONDE (Where) - Onde a ação começa?
4. QUANDO (When) - Em que período/época dentro da ambientação?
5. QUEM (Who) - Quem são as figuras centrais (aliados/inimigos)?
6. COMO (How) - Como os jogadores se envolveram?
7. QUANTO (How Much) - Qual o nível de letalidade e complexidade esperada?

IMPORTANTE: Seja específico, criativo e adequado ao sistema ${formData.system_rpg} e ambientação ${formData.setting}.`;

      const aiAnswers = await base44.integrations.Core.InvokeLLM({
        prompt: aiPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            what: { type: 'string' },
            why: { type: 'string' },
            where: { type: 'string' },
            when: { type: 'string' },
            who: { type: 'string' },
            how: { type: 'string' },
            how_much: { type: 'string' }
          },
          required: ['what', 'why', 'where', 'when', 'who', 'how', 'how_much']
        }
      });

      const questionsMap = [
        { key: 'what', title: 'O Quê? (What)', order: 1 },
        { key: 'why', title: 'Por Quê? (Why)', order: 2 },
        { key: 'where', title: 'Onde? (Where)', order: 3 },
        { key: 'when', title: 'Quando? (When)', order: 4 },
        { key: 'who', title: 'Quem? (Who)', order: 5 },
        { key: 'how', title: 'Como? (How)', order: 6 },
        { key: 'how_much', title: 'Quanto? (How Much)', order: 7 }
      ];

      const savePromises = questionsMap.map(q => 
        base44.entities.CampaignStep.create({
          campaign_id: campaignIdToUse,
          question_key: q.key,
          question_text: q.title,
          user_answer: aiAnswers[q.key] || 'Gerado pela IA',
          order_index: q.order
        })
      );

      await Promise.all(savePromises);

      await base44.entities.Campaign.update(campaignIdToUse, {
        current_step: 8,
        creativity_level: creativityLevel
      });

      // Ir para tela de criatividade (step 8)
      setCurrentStep(8);
      setGenerating(false);
      
    } catch (error) {
      console.error('Erro na geração completa:', error);
      alert('Erro ao gerar respostas 5W2H: ' + (error.message || 'Erro desconhecido'));
      setGenerating(false);
    }
  };

  const handleFinalGenerationDirect = async (campaignIdParam) => {
    try {
      const steps = await base44.entities.CampaignStep.filter({
        campaign_id: campaignIdParam
      });

      const answersText = steps
        .sort((a, b) => a.order_index - b.order_index)
        .map(s => `${s.question_text}: ${s.user_answer}`)
        .join('\n');

      const baseContext = `SISTEMA: ${formData.system_rpg}
  AMBIENTAÇÃO: ${formData.setting}
  DURAÇÃO: ${formData.duration_type}
  JOGADORES: ${formData.players_count}

  RESPOSTAS DO MESTRE:
  ${answersText}`;

      // ÚNICA ETAPA: Descrição com 5 Tópicos Específicos
      console.log('🎬 Gerando descrição da campanha...');
      const descriptionResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um mestre de RPG experiente. Crie uma DESCRIÇÃO COMPLETA da campanha.

  ${baseContext}

  TAREFA: Escreva 5 SEÇÕES DETALHADAS (mínimo 2000 caracteres total):

  1. INTRODUÇÃO (3-4 parágrafos)
  Apresentação geral da aventura, tom e atmosfera inicial.

  2. CONTEXTO DO MUNDO (3-4 parágrafos)
  Situação atual do mundo/região, facções importantes, história relevante, tensões existentes.

  3. CONFLITO CENTRAL (3-4 parágrafos)
  O problema principal que os jogadores enfrentarão. Por que é urgente? Quem está envolvido? O que está em jogo?

  4. ELEMENTOS ÚNICOS (2-3 parágrafos)
  O que torna esta campanha especial, memorável e diferente. Mecânicas únicas, reviravoltas, temas centrais.

  Seja EXTREMAMENTE detalhado e específico para ${formData.system_rpg} em ${formData.setting}.`,
        response_json_schema: {
          type: 'object',
          properties: {
            introduction: { type: 'string' },
            world_context: { type: 'string' },
            central_conflict: { type: 'string' },
            unique_elements: { type: 'string' }
          },
          required: ['introduction', 'world_context', 'central_conflict', 'unique_elements']
        }
      });
      console.log(`✅ Descrição gerada com ${Object.keys(descriptionResult).length} seções`);

      // Consolidar resultado final (SEM ganchos, arcos, NPCs)
      const finalContent = {
        campaign_description: `**INTRODUÇÃO**\n${descriptionResult.introduction}\n\n**CONTEXTO DO MUNDO**\n${descriptionResult.world_context}\n\n**CONFLITO CENTRAL**\n${descriptionResult.central_conflict}\n\n**ELEMENTOS ÚNICOS**\n${descriptionResult.unique_elements}`,
        plot_hooks: [],
        narrative_arcs: [],
        npcs: [],
        locations: [],
        wbs: { core_objective: 'A desenvolver' },
        antagonist_swot: { name: 'Antagonista', strengths: [], weaknesses: [], opportunities: [], threats: [] },
        stakeholders: [],
        decision_gateways: [],
        encounters: []
      };

      console.log('✅ DESCRIÇÃO COMPLETA!');
      console.log(`📊 ${finalContent.campaign_description.length} caracteres gerados`);

      // Salvar no banco
      await base44.entities.Campaign.update(campaignIdParam, {
        content_json: finalContent,
        is_completed: true,
        current_step: 8
      });
      console.log('💾 Campanha salva!');

      navigate(createPageUrl('CampaignView') + '?id=' + campaignIdParam);

      } catch (error) {
      console.error('❌ ERRO:', error);
      alert(`Erro: ${error.message}\n\nTente novamente.`);
      setGenerating(false);
      }
      };

      const handleFinalGeneration_OLD_BACKUP = async () => {
      // BACKUP DO CÓDIGO ANTIGO - NÃO DELETAR
      try {
      const steps = await base44.entities.CampaignStep.filter({
        campaign_id: activeCampaignId
      });

      const answersText = steps
        .sort((a, b) => a.order_index - b.order_index)
        .map(s => `${s.question_text}: ${s.user_answer}`)
        .join('\n');

      const isOneShot = formData.duration_type === 'One-shot';
      const isSeries = formData.duration_type === 'Série (4-6 sessões)';

      const numArcs = isOneShot ? 1 : isSeries ? 2 : 3;
      const numHooks = isOneShot ? 3 : isSeries ? 5 : 7;
      const numNpcs = isOneShot ? 3 : isSeries ? 5 : 7;
      const numEncounters = isOneShot ? 2 : isSeries ? 3 : 5;
      const numLocations = isOneShot ? 3 : isSeries ? 5 : 7;

      const baseContext = `SISTEMA: ${formData.system_rpg}
      AMBIENTAÇÃO: ${formData.setting}
      DURAÇÃO: ${formData.duration_type}
      JOGADORES: ${formData.players_count}

      RESPOSTAS DO MESTRE:
      ${answersText}`;

      console.log(`🎬 ETAPA 4/5: ${numNpcs} NPCs Detalhados...`);
      const npcsResult = await base44.integrations.Core.InvokeLLM({
        prompt: `BACKUP OLD CODE - DO NOT USE

ESTRUTURA OBRIGATÓRIA DE CADA NPC:
1. name: Nome completo
2. role: Papel na história (ex: "Vilão principal", "Aliado relutante", "Mentor sábio")
3. description: Descrição MUITO LONGA (15-20 frases): aparência física detalhada, personalidade profunda, história de vida, maneirismos únicos, jeito de falar
4. motivation: Motivação profunda (4-5 frases)
5. background_hook: Um gancho narrativo pessoal que conecta este NPC à história principal (3-4 frases)
6. relationships: Array com 2-4 relacionamentos com outros NPCs, cada um com:
   * npc_name: Nome do outro NPC
   * relationship_type: Tipo (amigo/inimigo/rival/mentor/aliado/familiar)
   * description: Descrição da relação (2-3 frases)
7. stats: Objeto com estatísticas ESPECÍFICAS para ${formData.system_rpg}:
   ${formData.system_rpg === 'D&D 5e' ? `
   * level: Nível do personagem (1-20)
   * class: Classe (ex: Guerreiro, Mago, Ladino)
   * hp: Pontos de vida
   * ac: Classe de armadura
   * str, dex, con, int, wis, cha: Atributos (8-20)
   * special_abilities: Array com 2-3 habilidades especiais
   ` : formData.system_rpg === 'Ordem Paranormal' ? `
   * nex: Nível de exposição paranormal (5-99%)
   * class: Classe (ex: Combatente, Especialista, Ocultista)
   * pv: Pontos de vida
   * pe: Pontos de esforço
   * defense: Defesa
   * for, agi, int, pre, vig: Atributos (1-5)
   * special_abilities: Array com 2-3 habilidades especiais
   ` : `
   * power_level: Nível de poder (1-10)
   * combat_skill: Habilidade de combate (1-10)
   * social_skill: Habilidade social (1-10)
   * special_abilities: Array com 2-3 habilidades especiais
   `}

IMPORTANTE:
- Sistema: ${formData.system_rpg}
- Seja EXTREMAMENTE ESPECÍFICO
- Stats devem ser apropriados para o sistema escolhido
- Relacionamentos devem ser interessantes e criar drama
- Background hooks devem conectar NPCs à trama principal`,
        response_json_schema: {
          type: 'object',
          properties: {
            npcs: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  role: { type: 'string' },
                  description: { type: 'string' },
                  motivation: { type: 'string' },
                  background_hook: { type: 'string' },
                  relationships: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        npc_name: { type: 'string' },
                        relationship_type: { type: 'string' },
                        description: { type: 'string' }
                      },
                      required: ['npc_name', 'relationship_type', 'description']
                    },
                    minItems: 2,
                    maxItems: 4
                  },
                  stats: { 
                    type: 'object',
                    properties: {
                      special_abilities: { type: 'array', items: { type: 'string' } }
                    }
                  }
                },
                required: ['name', 'role', 'description', 'motivation', 'background_hook', 'relationships', 'stats']
              },
              minItems: numNpcs,
              maxItems: numNpcs + 2
            }
          },
          required: ['npcs']
        }
      });
      console.log(`✅ NPCs: ${npcsResult.npcs.length}`);

      // ETAPA 5: LOCAÇÕES DETALHADAS E GESTÃO
      console.log(`🎬 ETAPA 5/5: ${numLocations} Locações + Gestão...`);
      const locationsAndManagementResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um mestre de RPG experiente. Crie LOCAÇÕES DETALHADAS e FERRAMENTAS DE GESTÃO para a campanha.

${baseContext}

TAREFA: Crie TODOS os elementos abaixo:

1. LOCATIONS (${numLocations} locações importantes):
   Cada locação deve ter:
   - name: Nome da locação (ex: "A Taberna do Dragão Dourado")
   - description: Descrição MUITO DETALHADA (8-10 frases): aparência, história, detalhes arquitetônicos/geográficos
   - atmosphere: Atmosfera/clima do local (3-4 frases descrevendo sons, cheiros, sensações)
   - points_of_interest: Array com 3-5 pontos de interesse específicos dentro da locação
   - possible_encounters: Array com 2-3 possíveis encontros que podem ocorrer aqui (cada um 2-3 frases)
   - connections: Como esta locação se conecta a outras (2-3 frases)
   - secrets: 1-2 segredos ocultos nesta locação

2. WBS (Work Breakdown Structure):
   - core_objective: Objetivo macro da campanha (1 frase)
   - narrative_arcs: Array com estrutura de arcos (nome e cenas-chave)

3. ANTAGONIST_SWOT:
   - name: Nome + título do antagonista
   - backstory: História dele (5-6 frases)
   - motivation: Motivação (3-4 frases)
   - strengths: 5-7 forças específicas
   - weaknesses: 5-7 fraquezas específicas
   - opportunities: 4-5 oportunidades que ele tem
   - threats: 4-5 ameaças contra ele

4. STAKEHOLDERS (3-6 personagens influentes):
   - name, title, archetype
   - power (1-10), interest (-10 a +10)
   - description, short_term_goal, long_term_ambition
   - shadow_file (segredos), connections (relacionamentos)

5. DECISION_GATEWAYS (3-5 pontos de decisão):
   - trigger: O que ativa
   - condition: Condição da escolha
   - consequence_a/b: Consequências
   - impact: Impacto geral

6. ENCOUNTERS (${numEncounters} encontros de combate):
   - name: Nome do encontro
   - difficulty: fácil/médio/difícil/mortal
   - description: Descrição da cena (4-5 frases)
   - creatures: Array com nomes de criaturas
   - tactics: Táticas dos inimigos (3-4 frases)

Sistema: ${formData.system_rpg}
Ambientação: ${formData.setting}
Seja EXTREMAMENTE DETALHADO e ESPECÍFICO.`,
        response_json_schema: {
          type: 'object',
          properties: {
            locations: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  description: { type: 'string' },
                  atmosphere: { type: 'string' },
                  points_of_interest: { type: 'array', items: { type: 'string' }, minItems: 3, maxItems: 5 },
                  possible_encounters: { type: 'array', items: { type: 'string' }, minItems: 2, maxItems: 3 },
                  connections: { type: 'string' },
                  secrets: { type: 'array', items: { type: 'string' }, minItems: 1, maxItems: 2 }
                },
                required: ['name', 'description', 'atmosphere', 'points_of_interest', 'possible_encounters', 'connections', 'secrets']
              },
              minItems: numLocations,
              maxItems: numLocations + 2
            },
            wbs: {
              type: 'object',
              properties: {
                core_objective: { type: 'string' },
                narrative_arcs: { type: 'array', items: { type: 'object' } }
              },
              required: ['core_objective', 'narrative_arcs']
            },
            antagonist_swot: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                backstory: { type: 'string' },
                motivation: { type: 'string' },
                strengths: { type: 'array', items: { type: 'string' }, minItems: 5 },
                weaknesses: { type: 'array', items: { type: 'string' }, minItems: 5 },
                opportunities: { type: 'array', items: { type: 'string' }, minItems: 4 },
                threats: { type: 'array', items: { type: 'string' }, minItems: 4 }
              },
              required: ['name', 'backstory', 'motivation', 'strengths', 'weaknesses', 'opportunities', 'threats']
            },
            stakeholders: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  title: { type: 'string' },
                  archetype: { type: 'string' },
                  power: { type: 'integer' },
                  interest: { type: 'integer' },
                  description: { type: 'string' }
                },
                required: ['name', 'power', 'interest', 'description']
              },
              minItems: 3
            },
            decision_gateways: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  trigger: { type: 'string' },
                  condition: { type: 'string' },
                  consequence_a: { type: 'string' },
                  consequence_b: { type: 'string' },
                  impact: { type: 'string' }
                },
                required: ['trigger', 'condition']
              },
              minItems: 3
            },
            encounters: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  difficulty: { type: 'string' },
                  description: { type: 'string' },
                  creatures: { type: 'array', items: { type: 'string' }, minItems: 1 },
                  tactics: { type: 'string' }
                },
                required: ['name', 'difficulty', 'description', 'creatures']
              },
              minItems: numEncounters
            }
          },
          required: ['locations', 'wbs', 'antagonist_swot', 'stakeholders', 'decision_gateways', 'encounters']
        }
      });
      console.log(`✅ Locações: ${locationsAndManagementResult.locations.length}, Encontros: ${locationsAndManagementResult.encounters.length}`)

            // Consolidar resultados
            const finalContent = {
              adventure_summary: descriptionResult.campaign_description,
              plot_hooks: hooksResult.plot_hooks,
              narrative_arcs: arcsResult.narrative_arcs,
              npcs: npcsResult.npcs,
              locations: locationsAndManagementResult.locations,
              wbs: locationsAndManagementResult.wbs,
              antagonist_swot: locationsAndManagementResult.antagonist_swot,
              stakeholders: locationsAndManagementResult.stakeholders || [],
              decision_gateways: locationsAndManagementResult.decision_gateways || [],
              encounters: locationsAndManagementResult.encounters
            };

            console.log('✅ GERAÇÃO COMPLETA!');
            console.log(`📊 Descrição: ${finalContent.adventure_summary.length} chars`);
            console.log(`📊 Ganchos: ${finalContent.plot_hooks.length}`);
            console.log(`📊 Arcos: ${finalContent.narrative_arcs.length}`);
            console.log(`📊 Atos: ${finalContent.narrative_arcs.reduce((sum, arc) => sum + arc.acts.length, 0)}`);
            console.log(`📊 Cenas: ${finalContent.narrative_arcs.reduce((sum, arc) => sum + arc.acts.reduce((s, act) => s + act.scenes.length, 0), 0)}`);
            console.log(`📊 NPCs: ${finalContent.npcs.length}`);
            console.log(`📊 Locações: ${finalContent.locations.length}`);
            console.log(`📊 Encontros: ${finalContent.encounters.length}`);

            // Salvar no banco
            await base44.entities.Campaign.update(campaignIdParam, {
              content_json: finalContent,
              is_completed: true,
              current_step: 8
            });
            console.log('💾 Campanha salva!');

            // Criar NPCs no banco
            console.log('🎭 Criando NPCs...');
            if (finalContent.npcs && finalContent.npcs.length > 0) {
              const npcPromises = finalContent.npcs
                .filter(npc => npc && npc.name && npc.description)
          .map(npc => {
            let npcType = 'NPC';
            const roleLower = (npc.role || '').toLowerCase();
            if (roleLower.includes('aliado')) npcType = 'Ally';
            else if (roleLower.includes('vilão') || roleLower.includes('antagonista')) npcType = 'Villain';
            
            return base44.entities.NpcCreature.create({
              campaign_id: campaignIdParam,
              name: npc.name,
              type: npcType,
              role: npc.role || 'Personagem',
              motivation: npc.motivation || 'Indefinida',
              description: npc.description,
              stats_json: {
                ...(npc.stats || {}),
                background_hook: npc.background_hook,
                relationships: npc.relationships
              }
            });
            });

            await Promise.all(npcPromises);
            console.log(`✅ ${npcPromises.length} NPCs criados`);
            }

            // Criar Stakeholders no banco
            if (finalContent.stakeholders && finalContent.stakeholders.length > 0) {
            const stakeholderNpcs = finalContent.stakeholders
            .filter(s => s && s.name && s.description && !finalContent.npcs.find(npc => npc.name === s.name))
          .map(s => {
            return base44.entities.NpcCreature.create({
              campaign_id: campaignIdParam,
              name: s.name,
              type: s.archetype === 'Obstrutor' || s.interest < 0 ? 'Villain' : s.archetype === 'Facilitador' && s.interest > 0 ? 'Ally' : 'NPC',
              role: s.title || 'Stakeholder',
              motivation: s.short_term_goal || 'A definir',
              description: s.description,
              stats_json: {
                power: s.power,
                interest: s.interest,
                archetype: s.archetype,
                long_term_ambition: s.long_term_ambition,
                shadow_file: s.shadow_file,
                connections: s.connections
              }
            });
            });

            if (stakeholderNpcs.length > 0) {
            await Promise.all(stakeholderNpcs);
            console.log(`✅ ${stakeholderNpcs.length} Stakeholders criados`);
            }
            }

            // Criar Monstros dos encontros
            if (finalContent.encounters && finalContent.encounters.length > 0) {
            const monsterPromises = [];
            finalContent.encounters.forEach((encounter, encIndex) => {
          if (encounter.creatures && encounter.creatures.length > 0) {
            encounter.creatures.forEach(creatureName => {
              if (creatureName && creatureName.length > 2) {
                monsterPromises.push(
                  base44.entities.NpcCreature.create({
                    campaign_id: campaignIdParam,
                    name: creatureName,
                    type: 'Monster',
                    role: `Encontro: ${encounter.name}`,
                    motivation: `${encounter.difficulty}`,
                    description: encounter.description || `Criatura do encontro ${encIndex + 1}`,
                    stats_json: {
                      encounter_index: encIndex,
                      difficulty: encounter.difficulty,
                      tactics: encounter.tactics
                    }
                  })
                );
              }
            });
          }
        });

        if (monsterPromises.length > 0) {
          await Promise.all(monsterPromises);
          console.log(`✅ ${monsterPromises.length} monstros criados`);
        }
      }

      console.log('🎉 TUDO CONCLUÍDO!');
      navigate(createPageUrl('CampaignView') + '?id=' + campaignIdParam);

    } catch (error) {
      console.error('❌ ERRO CRÍTICO:', error);
      
      const errorMsg = error.message || String(error);
      let userMessage = '❌ Erro ao gerar campanha:\n\n';
      
      if (errorMsg.includes('campaign_description')) {
        userMessage += 'Falha na ETAPA 1 (Descrição). ';
        console.error('Erro na descrição:', error);
      } else if (errorMsg.includes('plot_hooks')) {
        userMessage += 'Falha na ETAPA 2 (Ganchos). ';
        console.error('Erro nos ganchos:', error);
      } else if (errorMsg.includes('narrative_arcs') || errorMsg.includes('plot_twists') || errorMsg.includes('scenes')) {
        userMessage += 'Falha na ETAPA 3 (Arcos, Cenas e Plot Twists). ';
        console.error('Erro nos arcos narrativos:', error);
      } else if (errorMsg.includes('npcs') && !errorMsg.includes('locations')) {
        userMessage += 'Falha na ETAPA 4 (NPCs com Stats e Relacionamentos). ';
        console.error('Erro na geração de NPCs:', error);
      } else if (errorMsg.includes('locations') || errorMsg.includes('wbs') || errorMsg.includes('antagonist_swot') || errorMsg.includes('stakeholders') || errorMsg.includes('decision_gateways') || errorMsg.includes('encounters')) {
        userMessage += 'Falha na ETAPA 5 (Locações e Gestão). ';
        console.error('Erro na etapa de locações/gestão:', error);
      } else {
        userMessage += 'Falha desconhecida. ';
        console.error('Erro desconhecido:', error);
      }
      
      userMessage += '\n\nDetalhes: ' + errorMsg;
      userMessage += '\n\nTente novamente ou use valores mais simples.';
      
      alert(userMessage);
      setGenerating(false);
    }
  };

  const handleAnswerSubmit = async () => {
    if (!activeCampaignId) return;
    
    setLoading(true);
    const currentQuestion = QUESTIONS_5W2H[currentStep - 1];
    const answer = answers[currentQuestion.key] || '';

    try {
      const existingSteps = await base44.entities.CampaignStep.filter({
        campaign_id: activeCampaignId,
        question_key: currentQuestion.key
      });

      if (existingSteps.length > 0) {
        await base44.entities.CampaignStep.update(existingSteps[0].id, {
          user_answer: answer
        });
      } else {
        await base44.entities.CampaignStep.create({
          campaign_id: activeCampaignId,
          question_key: currentQuestion.key,
          question_text: currentQuestion.title,
          user_answer: answer,
          order_index: currentStep
        });
      }

      await base44.entities.Campaign.update(activeCampaignId, {
        current_step: currentStep + 1
      });

      if (currentStep < 7) {
        setCurrentStep(currentStep + 1);
      } else {
        setCurrentStep(8);
      }
    } catch (error) {
      console.error('Erro ao salvar resposta:', error);
      alert('Erro ao salvar resposta. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleFinalGeneration = async () => {
    if (!activeCampaignId) {
      alert('ID de campanha não encontrado');
      return;
    }
    
    setGenerating(true);

    try {
      const steps = await base44.entities.CampaignStep.filter({ campaign_id: activeCampaignId });

      if (!steps || steps.length < 7) {
        setGenerating(false);
        alert('Complete todas as 7 perguntas primeiro');
        return;
      }

      const answersText = steps
        .sort((a, b) => a.order_index - b.order_index)
        .map(s => `${s.question_text}: ${s.user_answer}`)
        .join('\n\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um designer de campanhas profissional de RPG. Crie uma DESCRIÇÃO GERAL DA CAMPANHA seguindo a estrutura abaixo. O texto deve ser enciclopédico, mas inspirador. MÍNIMO DE 2500 CARACTERES.

SISTEMA: ${formData.system_rpg}
AMBIENTAÇÃO: ${formData.setting}
DURAÇÃO: ${formData.duration_type}
JOGADORES: ${formData.players_count}
CRIATIVIDADE: ${creativityLevel}/5

RESPOSTAS 5W2H DO MESTRE:
${answersText}

ESTRUTURA OBRIGATÓRIA:

1. PREMISSA:
   - Pitch (2-3 frases): Protagonistas + Ação Central + Antagonista/Obstáculo
   - O "E Se?": Pergunta fundamental que altera o status quo
   - Promessa de Experiência: O que os jogadores sentirão?
   - Função dos Personagens: Quem são e qual seu objetivo
   - Proposta de Jogo: Gênero refinado e o que farão na maior parte do tempo
   - Escala: Escopo da campanha (vila, reino, multiverso?) e nível de progressão

2. CONTEXTO DO MUNDO:
   - Geografia e Atmosfera: Regiões de interesse, clima, arquitetura
   - Paleta Sensorial: Cores, cheiros e sons predominantes
   - Sociedade e Cultura: Como vivem, o que é crime, o que é sagrado
   - História Recente: Últimos 50 anos que moldaram o presente
   - Letalidade e Moralidade: Cinematográfica/Maniqueísta ou Crua/Cinza

3. CONFLITO CENTRAL:
   - Origem do Problema: O que quebrou o status quo?
   - Facções Envolvidas: Quem são os grandes players?
   - O Que Está em Jogo: Por que isso importa?
   - Tensão Política/Social: Quem oprime quem? Qual escassez?
   - Inimigo Oculto vs. Visível: Diferença entre ameaça imediata e existencial

4. FORÇAS DE PODER (2-3 facções principais):
   Para cada facção:
   - Desejo: O que querem desesperadamente?
   - Recurso: O que têm em abundância?
   - Carência: O que precisam e não conseguem sozinhos?

5. ASPECTOS DA CAMPANHA (3-5 fatos absolutos):
   Características únicas que diferenciam este cenário

6. RELÓGIO DO APOCALIPSE:
   Cronograma de 3-5 estágios do que acontece se os heróis não agirem

IMPORTANTE:
- Seja específico para ${formData.system_rpg} em ${formData.setting}
- Use as respostas 5W2H como base fundamental
- Texto deve ter NO MÍNIMO 2500 caracteres
- Estilo enciclopédico mas inspirador
- Foco em conflitos macro e motivadores universais`,
        response_json_schema: {
          type: 'object',
          properties: {
            premissa: {
              type: 'object',
              properties: {
                pitch: { type: 'string' },
                e_se: { type: 'string' },
                promessa_experiencia: { type: 'string' },
                funcao_personagens: { type: 'string' },
                proposta_jogo: { type: 'string' },
                escala: { type: 'string' }
              },
              required: ['pitch', 'e_se', 'promessa_experiencia', 'funcao_personagens', 'proposta_jogo', 'escala']
            },
            contexto_mundo: {
              type: 'object',
              properties: {
                geografia_atmosfera: { type: 'string' },
                paleta_sensorial: { type: 'string' },
                sociedade_cultura: { type: 'string' },
                historia_recente: { type: 'string' },
                letalidade_moralidade: { type: 'string' }
              },
              required: ['geografia_atmosfera', 'paleta_sensorial', 'sociedade_cultura', 'historia_recente', 'letalidade_moralidade']
            },
            conflito_central: {
              type: 'object',
              properties: {
                origem_problema: { type: 'string' },
                faccoes_envolvidas: { type: 'string' },
                stakes: { type: 'string' },
                tensao_politica: { type: 'string' },
                inimigos: { type: 'string' }
              },
              required: ['origem_problema', 'faccoes_envolvidas', 'stakes', 'tensao_politica', 'inimigos']
            },
            forcas_poder: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  nome: { type: 'string' },
                  desejo: { type: 'string' },
                  recurso: { type: 'string' },
                  carencia: { type: 'string' }
                },
                required: ['nome', 'desejo', 'recurso', 'carencia']
              },
              minItems: 2,
              maxItems: 4
            },
            aspectos_campanha: {
              type: 'array',
              items: { type: 'string' },
              minItems: 3,
              maxItems: 5
            },
            relogio_apocalipse: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  estagio: { type: 'string' },
                  descricao: { type: 'string' },
                  tempo_estimado: { type: 'string' }
                },
                required: ['estagio', 'descricao', 'tempo_estimado']
              },
              minItems: 3,
              maxItems: 5
            }
          },
          required: ['premissa', 'contexto_mundo', 'conflito_central', 'forcas_poder', 'aspectos_campanha', 'relogio_apocalipse']
        }
      });

      const fullDescription = `# 1. PREMISSA

**Pitch**
${result.premissa.pitch}

**O "E Se?"**
${result.premissa.e_se}

**Promessa de Experiência**
${result.premissa.promessa_experiencia}

**Função dos Personagens**
${result.premissa.funcao_personagens}

**Proposta de Jogo**
${result.premissa.proposta_jogo}

**Escala**
${result.premissa.escala}

---

# 2. CONTEXTO DO MUNDO

**Geografia e Atmosfera**
${result.contexto_mundo.geografia_atmosfera}

**Paleta Sensorial**
${result.contexto_mundo.paleta_sensorial}

**Sociedade e Cultura**
${result.contexto_mundo.sociedade_cultura}

**História Recente**
${result.contexto_mundo.historia_recente}

**Letalidade e Moralidade**
${result.contexto_mundo.letalidade_moralidade}

---

# 3. CONFLITO CENTRAL

**Origem do Problema**
${result.conflito_central.origem_problema}

**Facções Envolvidas**
${result.conflito_central.faccoes_envolvidas}

**O Que Está em Jogo**
${result.conflito_central.stakes}

**Tensão Política/Social**
${result.conflito_central.tensao_politica}

**Inimigo Oculto vs. Visível**
${result.conflito_central.inimigos}

---

# 4. FORÇAS DE PODER

${result.forcas_poder.map(f => `**${f.nome}**
- **Desejo:** ${f.desejo}
- **Recurso:** ${f.recurso}
- **Carência:** ${f.carencia}`).join('\n\n')}

---

# 5. ASPECTOS DA CAMPANHA

${result.aspectos_campanha.map((a, i) => `${i + 1}. ${a}`).join('\n')}

---

# 6. RELÓGIO DO APOCALIPSE

${result.relogio_apocalipse.map((r, i) => `**${r.estagio}** (${r.tempo_estimado})
${r.descricao}`).join('\n\n')}`;

      await base44.entities.Campaign.update(activeCampaignId, {
        content_json: {
          campaign_description: fullDescription,
          adventure_summary: fullDescription,
          plot_hooks: [],
          narrative_arcs: [],
          npcs: [],
          locations: [],
          wbs: { core_objective: 'A desenvolver' },
          antagonist_swot: { name: 'Antagonista', strengths: [], weaknesses: [], opportunities: [], threats: [] },
          stakeholders: [],
          decision_gateways: [],
          encounters: []
        },
        is_completed: true,
        creativity_level: creativityLevel
      });
      
      setGenerating(false);
      window.location.href = createPageUrl('CampaignView') + '?id=' + activeCampaignId;

    } catch (error) {
      setGenerating(false);
      alert('Erro: ' + (error.message || String(error)));
    }
  };

  if (currentStep === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => navigate(createPageUrl('Dashboard'))}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Dashboard
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Wand2 className="w-10 h-10 text-purple-400" />
            <h1 className="text-4xl font-bold text-white">
              Novo Gerador de Campanha
            </h1>
          </div>
          <p className="text-slate-400 text-lg">
            Vamos começar definindo os parâmetros básicos da sua aventura
          </p>
        </div>

        <form onSubmit={handleInitialSubmit} className="space-y-6">
          <div className="p-8 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl space-y-6">
            <div>
              <Label htmlFor="title" className="text-white mb-2 block">
                Título da Campanha *
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ex: A Maldição do Templo Esquecido"
                required
                className="bg-slate-950/50 border-slate-700 text-white"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="system" className="text-white mb-2 block">
                  Sistema de RPG *
                </Label>
                <Select
                  value={formData.system_rpg}
                  onValueChange={(value) => setFormData({ ...formData, system_rpg: value })}
                >
                  <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSystems.map((system) => (
                      <SelectItem key={system.id} value={system.name}>
                        {system.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="setting" className="text-white mb-2 block">
                  Ambientação *
                </Label>
                <Select
                  value={formData.setting}
                  onValueChange={(value) => setFormData({ ...formData, setting: value })}
                >
                  <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Fantasia Medieval">Fantasia Medieval</SelectItem>
                    <SelectItem value="Cyberpunk">Cyberpunk</SelectItem>
                    <SelectItem value="Pós-Apocalíptico">Pós-Apocalíptico</SelectItem>
                    <SelectItem value="Terror/Horror">Terror/Horror</SelectItem>
                    <SelectItem value="Investigação">Investigação</SelectItem>
                    <SelectItem value="Espacial/Sci-Fi">Espacial/Sci-Fi</SelectItem>
                    <SelectItem value="Contemporâneo">Contemporâneo</SelectItem>
                    <SelectItem value="Outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="duration" className="text-white mb-2 block">
                  Duração *
                </Label>
                <Select
                  value={formData.duration_type}
                  onValueChange={(value) => setFormData({ ...formData, duration_type: value })}
                >
                  <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="One-shot">One-shot</SelectItem>
                    <SelectItem value="Série (4-6 sessões)">Série (4-6 sessões)</SelectItem>
                    <SelectItem value="Campanha Longa">Campanha Longa</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="players" className="text-white mb-2 block">
                  Número de Jogadores *
                </Label>
                <Input
                  id="players"
                  type="number"
                  min="1"
                  max="10"
                  value={formData.players_count}
                  onChange={(e) => setFormData({ ...formData, players_count: parseInt(e.target.value) })}
                  required
                  className="bg-slate-950/50 border-slate-700 text-white"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button
              type="submit"
              disabled={loading || generating}
              className="px-8 py-3 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white rounded-xl font-semibold transition-all shadow-lg flex items-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  Iniciar Interrogatório 5W2H
                  <Sparkles className="w-5 h-5" />
                </>
              )}
            </Button>

            {isAdmin && (
              <Button
                type="button"
                onClick={handleAIFullGeneration}
                disabled={loading || generating}
                className="px-8 py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white rounded-xl font-semibold transition-all shadow-lg flex items-center gap-2"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Criando com IA...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    Criar Tudo com IA (Admin)
                  </>
                )}
              </Button>
            )}
          </div>
        </form>
      </div>
    );
  }

  if (currentStep >= 1 && currentStep <= 7) {
    const question = QUESTIONS_5W2H[currentStep - 1];
    
    return (
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => currentStep === 1 ? setCurrentStep(0) : setCurrentStep(currentStep - 1)}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            {formData.title}
          </h1>
          <p className="text-slate-400">
            {formData.system_rpg} • {formData.setting}
          </p>
        </div>

        <ProgressBar currentStep={currentStep - 1} totalSteps={7} />

        <QuestionCard
          question={question}
          answer={answers[question.key] || ''}
          onChange={(value) => setAnswers({ ...answers, [question.key]: value })}
          onNext={handleAnswerSubmit}
          isLoading={loading}
        />
      </div>
    );
  }

  if (currentStep === 8) {
    return (
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => setCurrentStep(7)}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Nível de Criatividade
          </h1>
          <p className="text-slate-400 text-lg">
            Escolha quanta liberdade criativa a IA terá ao gerar sua campanha
          </p>
        </div>

        <div className="p-8 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl space-y-8">
          <div>
            <div className="flex justify-between items-center mb-4">
              <Label className="text-white text-lg">
                Nível: <span className="text-purple-400 font-bold">{creativityLevel}</span>
              </Label>
              <span className="text-sm text-slate-400">
                {creativityLevel === 0 && 'Totalmente Fiel'}
                {creativityLevel === 1 && 'Muito Fiel'}
                {creativityLevel === 2 && 'Equilibrado'}
                {creativityLevel === 3 && 'Criativo'}
                {creativityLevel === 4 && 'Muito Criativo'}
                {creativityLevel === 5 && 'Liberdade Total'}
              </span>
            </div>
            
            <input
              type="range"
              min="0"
              max="5"
              value={creativityLevel}
              onChange={(e) => setCreativityLevel(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-600"
            />

            <div className="flex justify-between text-xs text-slate-500 mt-2">
              <span>0</span>
              <span>1</span>
              <span>2</span>
              <span>3</span>
              <span>4</span>
              <span>5</span>
            </div>
          </div>

          <div className="p-6 bg-purple-900/10 border border-purple-500/20 rounded-lg">
            <h3 className="text-white font-semibold mb-2">
              {creativityLevel <= 1 && 'Modo Fiel'}
              {creativityLevel === 2 && 'Modo Equilibrado'}
              {creativityLevel === 3 && 'Modo Criativo'}
              {creativityLevel >= 4 && 'Modo Livre'}
            </h3>
            <p className="text-slate-400 text-sm">
              {creativityLevel === 0 && 'A IA seguirá estritamente suas respostas, sem adicionar elementos extras.'}
              {creativityLevel === 1 && 'A IA seguirá suas respostas com pequenos detalhes adicionais.'}
              {creativityLevel === 2 && 'A IA usará suas respostas como base e adicionará elementos criativos moderados.'}
              {creativityLevel === 3 && 'A IA terá liberdade para expandir suas ideias com criatividade.'}
              {creativityLevel === 4 && 'A IA criará conteúdo muito além do básico, com reviravoltas inesperadas.'}
              {creativityLevel === 5 && 'A IA terá liberdade total para criar, usando suas respostas apenas como inspiração.'}
            </p>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <Button
            onClick={handleFinalGeneration}
            disabled={generating}
            className="px-10 py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white rounded-xl font-bold text-lg transition-all shadow-lg shadow-purple-500/30 flex items-center gap-3"
          >
            {generating ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Gerando sua campanha...
              </>
            ) : (
              <>
                <Sparkles className="w-6 h-6" />
                Gerar Descrição da Campanha
              </>
              )}
              </Button>
              <p className="text-slate-400 text-sm text-center mt-4">
              Após isso, você poderá criar ganchos, arcos e NPCs de forma individual
              </p>
        </div>
      </div>
    );
  }

  return null;
}