import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus } from 'lucide-react';

export default function GenerateArcDialog({ campaignId, campaign, onArcGenerated }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [arcName, setArcName] = useState('');
  const [missionType, setMissionType] = useState('investigação');
  const [numActs, setNumActs] = useState(3);

  const handleGenerate = async () => {
    if (!arcName.trim()) {
      alert('Digite um nome para o arco');
      return;
    }

    setLoading(true);
    try {
      const steps = await base44.entities.CampaignStep.filter({ campaign_id: campaignId });
      const answersText = steps
        .sort((a, b) => a.order_index - b.order_index)
        .map(s => `${s.question_text}: ${s.user_answer}`)
        .join('\n');

      const description = campaign.content_json?.campaign_description || {};

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Crie um arco narrativo completo para a campanha.

INFORMAÇÕES:
Sistema: ${campaign.system_rpg}
Ambientação: ${campaign.setting}
Nome do Arco: ${arcName}
Tipo de Missão: ${missionType}
Número de Atos: ${numActs}

RESPOSTAS 5W2H:
${answersText}

DESCRIÇÃO:
${description.introduction || ''}
${description.world_context || ''}
${description.central_conflict || ''}

CRIE UM ARCO COM:
- name: "${arcName}"
- description: Resumo do arco focado em missão de ${missionType} (4-5 frases)
- objective: Objetivo principal claro (2 frases)
- plot_twists: 2 reviravoltas relacionadas a ${missionType}
- acts: EXATAMENTE ${numActs} atos

CADA ATO:
- title: Nome do ato
- description: O que acontece (4-5 frases)
- objectives: 3 objetivos
- interactions: 3 interações
- clues: 3 pistas
- npcs_involved: 2 NPCs
- scenes: 2 cenas completas
- challenges: 2 desafios relacionados a ${missionType}
- rewards: Recompensas

CENA:
- scene_name, scene_description (4 frases), location, mood, transition

DESAFIO:
- type, description (3 frases), difficulty`,
        response_json_schema: {
          type: 'object',
          properties: {
            arc: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                description: { type: 'string' },
                objective: { type: 'string' },
                mission_type: { type: 'string' },
                plot_twists: { type: 'array', items: { type: 'string' } },
                acts: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string' },
                      description: { type: 'string' },
                      objectives: { type: 'array', items: { type: 'string' } },
                      interactions: { type: 'array', items: { type: 'string' } },
                      clues: { type: 'array', items: { type: 'string' } },
                      npcs_involved: { type: 'array', items: { type: 'string' } },
                      scenes: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            scene_name: { type: 'string' },
                            scene_description: { type: 'string' },
                            location: { type: 'string' },
                            mood: { type: 'string' },
                            transition: { type: 'string' }
                          }
                        }
                      },
                      challenges: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            type: { type: 'string' },
                            description: { type: 'string' },
                            difficulty: { type: 'string' }
                          }
                        }
                      },
                      rewards: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        }
      });

      // Adicionar arco ao array existente
      const content = campaign.content_json || {};
      const existingArcs = content.narrative_arcs || [];
      
      await base44.entities.Campaign.update(campaignId, {
        content_json: {
          ...content,
          narrative_arcs: [...existingArcs, { ...result.arc, mission_type: missionType }]
        }
      });

      onArcGenerated();
      setOpen(false);
      setArcName('');
    } catch (error) {
      console.error('Erro ao gerar arco:', error);
      alert('Erro ao gerar arco: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Criar Novo Arco
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-slate-900 border-purple-900/30 text-white">
        <DialogHeader>
          <DialogTitle>Criar Arco Narrativo</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Nome do Arco</Label>
            <Input
              value={arcName}
              onChange={(e) => setArcName(e.target.value)}
              placeholder="Ex: A Conspiração do Templo"
              className="bg-slate-950/50 border-slate-700 text-white mt-1"
            />
          </div>

          <div>
            <Label>Tipo de Missão</Label>
            <Select value={missionType} onValueChange={setMissionType}>
              <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="investigação">Investigação</SelectItem>
                <SelectItem value="exploração">Exploração</SelectItem>
                <SelectItem value="roubo">Roubo</SelectItem>
                <SelectItem value="assassinato">Assassinato</SelectItem>
                <SelectItem value="resgate">Resgate</SelectItem>
                <SelectItem value="infiltração">Infiltração</SelectItem>
                <SelectItem value="diplomacia">Diplomacia</SelectItem>
                <SelectItem value="combate">Combate</SelectItem>
                <SelectItem value="proteção">Proteção</SelectItem>
                <SelectItem value="busca">Busca por Artefato</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Número de Atos (2-5)</Label>
            <input
              type="range"
              min="2"
              max="5"
              value={numActs}
              onChange={(e) => setNumActs(parseInt(e.target.value))}
              className="w-full mt-2"
            />
            <div className="text-center text-purple-400 font-bold text-2xl">
              {numActs} atos
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Gerando...
              </>
            ) : (
              'Gerar Arco'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}