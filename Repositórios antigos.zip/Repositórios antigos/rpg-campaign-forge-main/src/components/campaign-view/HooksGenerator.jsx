import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Anchor, Sparkles, Loader2, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function HooksGenerator({ campaignId, description, answers5W2H, systemRpg, setting, onHooksGenerated }) {
  const [quantity, setQuantity] = useState(5);
  const [generating, setGenerating] = useState(false);
  const [customInstructions, setCustomInstructions] = useState('');
  const [generatedHooks, setGeneratedHooks] = useState([]);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Crie EXATAMENTE ${quantity} ganchos de aventura para uma campanha de ${systemRpg} em ${setting}.

CONTEXTO 5W2H:
${answers5W2H}

DESCRIÇÃO DA CAMPANHA:
${description.substring(0, 1000)}

${customInstructions ? `INSTRUÇÕES ESPECÍFICAS DO MESTRE:\n${customInstructions}\n\n` : ''}

TAREFA: Gere ${quantity} ganchos DIFERENTES e CRIATIVOS.

Cada gancho deve:
- Ter 5-7 frases completas
- Descrever uma forma única dos jogadores iniciarem a aventura
- Incluir: situação inicial, evento gatilho, urgência, e motivação
- Ser específico para ${systemRpg} e ${setting}
- Conectar-se ao conflito central da campanha`,
        response_json_schema: {
          type: 'object',
          properties: {
            hooks: {
              type: 'array',
              items: { 
                type: 'object',
                properties: {
                  hook: { type: 'string' }
                },
                required: ['hook']
              },
              minItems: quantity,
              maxItems: quantity
            }
          },
          required: ['hooks']
        }
      });

      // Extrair as strings do formato {hook: "texto"}
      const hooksArray = (result.hooks || []).map(item => 
        typeof item === 'string' ? item : item.hook
      );
      
      setGeneratedHooks(hooksArray);
      if (onHooksGenerated) {
        onHooksGenerated(hooksArray);
      }
    } catch (error) {
      console.error('Erro ao gerar ganchos:', error);
      alert('Erro ao gerar ganchos: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteHook = (index) => {
    const newHooks = generatedHooks.filter((_, i) => i !== index);
    setGeneratedHooks(newHooks);
    if (onHooksGenerated) {
      onHooksGenerated(newHooks);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/50 backdrop-blur-xl border-amber-900/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Sparkles className="w-6 h-6 text-amber-400" />
            Gerador de Ganchos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-slate-300">Quantidade de Ganchos (3-10)</Label>
            <Input
              type="number"
              min="3"
              max="10"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value))}
              className="bg-slate-950/50 border-slate-700 text-white mt-2"
            />
          </div>

          <div>
            <Label className="text-slate-300">Instruções Específicas (Opcional)</Label>
            <Textarea
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder="Ex: Focar em ganchos urbanos, incluir elementos de conspiração política..."
              className="bg-slate-950/50 border-slate-700 text-white mt-2 min-h-[100px]"
            />
          </div>

          <Button
            onClick={handleGenerate}
            disabled={generating}
            className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600"
          >
            {generating ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Gerando {quantity} ganchos...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Gerar {quantity} Ganchos
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {generatedHooks.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Anchor className="w-6 h-6 text-amber-400" />
            Ganchos Gerados ({generatedHooks.length})
          </h3>
          {generatedHooks.map((hook, index) => (
            <Card key={index} className="bg-slate-900/50 backdrop-blur-xl border-amber-900/20">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white">Gancho {index + 1}</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteHook(index)}
                    className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{hook}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}