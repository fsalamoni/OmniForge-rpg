import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Pencil, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function EditNpcDialog({ npc, onUpdate }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const stats = npc.stats_json || {};
  const shadowFile = stats.shadow_file || {};
  const connections = stats.connections || {};
  
  const [formData, setFormData] = useState({
    name: npc.name,
    role: npc.role,
    type: npc.type,
    motivation: npc.motivation,
    description: npc.description,
    power: stats.power || 5,
    interest: stats.interest || 0,
    archetype: stats.archetype || '',
    long_term_ambition: stats.long_term_ambition || '',
    operational_secret: shadowFile.operational_secret || '',
    vulnerability: shadowFile.vulnerability || '',
    hidden_agenda: shadowFile.hidden_agenda || '',
    connection_primary: connections.primary || '',
    connection_conflict: connections.conflict || '',
    resource_dependency: connections.resource_dependency || ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await base44.entities.NpcCreature.update(npc.id, {
        name: formData.name,
        role: formData.role,
        type: formData.type,
        motivation: formData.motivation,
        description: formData.description,
        stats_json: {
          power: parseInt(formData.power),
          interest: parseInt(formData.interest),
          archetype: formData.archetype,
          long_term_ambition: formData.long_term_ambition,
          shadow_file: {
            operational_secret: formData.operational_secret,
            vulnerability: formData.vulnerability,
            hidden_agenda: formData.hidden_agenda
          },
          connections: {
            primary: formData.connection_primary,
            conflict: formData.connection_conflict,
            resource_dependency: formData.resource_dependency
          }
        }
      });

      onUpdate();
      setOpen(false);
    } catch (error) {
      console.error('Erro ao atualizar NPC:', error);
      alert('Erro ao atualizar NPC. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-slate-400 hover:text-white"
        >
          <Pencil className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-slate-900 border-purple-900/20">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">Editar Stakeholder</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Informações Básicas */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300">Informações Básicas</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">Nome</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-slate-950/50 border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <Label className="text-slate-300">Cargo/Título</Label>
                <Input
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="bg-slate-950/50 border-slate-700 text-white"
                />
              </div>

              <div>
                <Label className="text-slate-300">Tipo</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                  <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="NPC">NPC</SelectItem>
                    <SelectItem value="Ally">Aliado</SelectItem>
                    <SelectItem value="Villain">Vilão</SelectItem>
                    <SelectItem value="Monster">Monstro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300">Arquétipo</Label>
                <Select value={formData.archetype} onValueChange={(value) => setFormData({ ...formData, archetype: value })}>
                  <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                    <SelectValue placeholder="Selecione..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Facilitador">Facilitador</SelectItem>
                    <SelectItem value="Obstrutor">Obstrutor</SelectItem>
                    <SelectItem value="Oportunista">Oportunista</SelectItem>
                    <SelectItem value="Recurso Chave">Recurso Chave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-slate-300">Descrição Completa</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white min-h-[100px]"
                placeholder="Aparência física, personalidade, maneirismos..."
              />
            </div>
          </div>

          {/* Matriz de Influência */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300">Matriz de Influência</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">Poder (1-10)</Label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={formData.power}
                  onChange={(e) => setFormData({ ...formData, power: e.target.value })}
                  className="bg-slate-950/50 border-slate-700 text-white"
                />
              </div>

              <div>
                <Label className="text-slate-300">Interesse (-10 a 10)</Label>
                <Input
                  type="number"
                  min="-10"
                  max="10"
                  value={formData.interest}
                  onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                  className="bg-slate-950/50 border-slate-700 text-white"
                />
              </div>
            </div>
          </div>

          {/* Motivações */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300">Motivações</h3>
            
            <div>
              <Label className="text-slate-300">Objetivo de Curto Prazo</Label>
              <Textarea
                value={formData.motivation}
                onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                rows={2}
              />
            </div>

            <div>
              <Label className="text-slate-300">Ambição de Longo Prazo</Label>
              <Textarea
                value={formData.long_term_ambition}
                onChange={(e) => setFormData({ ...formData, long_term_ambition: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                rows={2}
              />
            </div>
          </div>

          {/* Shadow File */}
          <div className="space-y-4 bg-red-900/10 border border-red-500/20 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-red-300">Shadow File 🔒</h3>
            
            <div>
              <Label className="text-slate-300">Segredo Operacional</Label>
              <Textarea
                value={formData.operational_secret}
                onChange={(e) => setFormData({ ...formData, operational_secret: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                rows={2}
                placeholder="Informação crítica que pode alterar a campanha..."
              />
            </div>

            <div>
              <Label className="text-slate-300">Vulnerabilidade</Label>
              <Textarea
                value={formData.vulnerability}
                onChange={(e) => setFormData({ ...formData, vulnerability: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                rows={2}
                placeholder="Ponto de alavancagem, medo, vício..."
              />
            </div>

            <div>
              <Label className="text-slate-300">Agenda Oculta</Label>
              <Textarea
                value={formData.hidden_agenda}
                onChange={(e) => setFormData({ ...formData, hidden_agenda: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                rows={2}
                placeholder="Objetivo que contradiz sua posição pública..."
              />
            </div>
          </div>

          {/* Vínculos Operacionais */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300">Vínculos Operacionais</h3>
            
            <div>
              <Label className="text-slate-300">Conexão Primária (Aliado)</Label>
              <Input
                value={formData.connection_primary}
                onChange={(e) => setFormData({ ...formData, connection_primary: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                placeholder="Nome do NPC ou facção aliada..."
              />
            </div>

            <div>
              <Label className="text-slate-300">Conexão de Conflito (Rival)</Label>
              <Input
                value={formData.connection_conflict}
                onChange={(e) => setFormData({ ...formData, connection_conflict: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                placeholder="Nome do NPC ou facção rival..."
              />
            </div>

            <div>
              <Label className="text-slate-300">Dependência de Recurso</Label>
              <Input
                value={formData.resource_dependency}
                onChange={(e) => setFormData({ ...formData, resource_dependency: e.target.value })}
                className="bg-slate-950/50 border-slate-700 text-white"
                placeholder="Recurso que controla ou necessita..."
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="border-slate-700 text-slate-300"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                'Salvar Alterações'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}