import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, Sparkles } from 'lucide-react';

export default function GenerateNpcDialog({ campaignId, systemRpg, setting, onNpcCreated }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [npcType, setNpcType] = useState('NPC');
  const [archetype, setArchetype] = useState('');
  const [useContext, setUseContext] = useState(true);
  const [instructions, setInstructions] = useState('');
  const [campaignContent, setCampaignContent] = useState(null);

  useEffect(() => {
    const loadCampaignContext = async () => {
      try {
        const campaigns = await base44.entities.Campaign.list();
        const campaign = campaigns.find(c => c.id === campaignId);
        if (campaign && campaign.content_json) {
          setCampaignContent(campaign.content_json);
        }
      } catch (error) {
        console.error('Erro ao carregar contexto da campanha:', error);
      }
    };
    
    if (campaignId) {
      loadCampaignContext();
    }
  }, [campaignId]);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      let contextInfo = '';
      
      if (useContext && campaignContent) {
        // Adicionar contexto da WBS
        if (campaignContent.wbs) {
          contextInfo += `\n\nOBJETIVO DA CAMPANHA: ${campaignContent.wbs.core_objective || 'Não especificado'}`;
          
          if (campaignContent.wbs.narrative_arcs && campaignContent.wbs.narrative_arcs.length > 0) {
            contextInfo += `\n\nARCOS NARRATIVOS:`;
            campaignContent.wbs.narrative_arcs.forEach((arc, i) => {
              contextInfo += `\n${i + 1}. ${arc.name}: ${arc.description}`;
            });
          }
        }
        
        // Adicionar contexto do SWOT do Antagonista
        if (campaignContent.antagonist_swot) {
          const swot = campaignContent.antagonist_swot;
          contextInfo += `\n\nANTAGONISTA PRINCIPAL: ${swot.name || 'Não especificado'}`;
          if (swot.strengths && swot.strengths.length > 0) {
            contextInfo += `\nForças: ${swot.strengths.join(', ')}`;
          }
          if (swot.weaknesses && swot.weaknesses.length > 0) {
            contextInfo += `\nFraquezas: ${swot.weaknesses.join(', ')}`;
          }
        }
        
        // Adicionar contexto de Stakeholders existentes
        if (campaignContent.stakeholders && campaignContent.stakeholders.length > 0) {
          contextInfo += `\n\nSTAKEHOLDERS EXISTENTES:`;
          campaignContent.stakeholders.forEach((s, i) => {
            contextInfo += `\n- ${s.name} (${s.title}): ${s.archetype}`;
          });
        }
      }

      const archetypeInstruction = archetype ? `\nARQUÉTIPO OPERACIONAL REQUERIDO: ${archetype}` : '';

      const prompt = `Você é um Arquiteto de Narrativa especializado em criar personagens profundos e integrados à estrutura da campanha.

SISTEMA: ${systemRpg}
AMBIENTAÇÃO: ${setting}
TIPO DE PERSONAGEM: ${npcType}
${archetypeInstruction}
${contextInfo}

${instructions ? `INSTRUÇÕES ESPECÍFICAS:\n${instructions}\n` : ''}

TAREFA: Crie um ${npcType} orgânico à estrutura da campanha com os seguintes requisitos:

═══════════════════════════════════════════════════════
1. APARÊNCIA FÍSICA DETALHADA (mínimo 5 frases):
═══════════════════════════════════════════════════════
- Altura, compleição, peso aproximado
- Cor de olhos, cabelos (estilo, comprimento, cor), pele
- Roupas típicas (tecidos, cores, estilo, estado de conservação)
- Traços marcantes (cicatrizes, tatuagens, marcas de nascença)
- Acessórios distintivos (joias, armas, ferramentas)
- Linguagem corporal (postura, gestos típicos)

═══════════════════════════════════════════════════════
2. PERSONALIDADE E MANEIRISMOS (mínimo 5 frases):
═══════════════════════════════════════════════════════
- Temperamento dominante (fleumático, colérico, melancólico, sanguíneo)
- Forma de falar (sotaque, gírias, vocabulário, tom de voz)
- Maneirismos únicos (tocar o rosto, tamborilar dedos, olhar fixo)
- Vícios e hábitos (fumar, beber, colecionismo)
- Medos e fobias
- Sentido de humor (sarcástico, ingênuo, sádico, ausente)

═══════════════════════════════════════════════════════
3. BACKGROUND E ORIGEM (mínimo 5 frases):
═══════════════════════════════════════════════════════
- Origem familiar e classe social
- Evento formativo mais importante (trauma, conquista, perda)
- Como chegou à posição atual (ascensão, queda, sorte, mérito)
- Relacionamentos significativos passados
- Educação e treinamento

═══════════════════════════════════════════════════════
4. MOTIVAÇÕES E OBJETIVOS:
═══════════════════════════════════════════════════════
- Objetivo de curto prazo (o que quer AGORA)
- Ambição de longo prazo (o que quer no futuro distante)
- O que o personagem mais valoriza (família, poder, conhecimento, liberdade)
- O que está disposto a sacrificar para alcançar seus objetivos

═══════════════════════════════════════════════════════
5. RELAÇÕES COM OUTROS NPCs:
═══════════════════════════════════════════════════════
${useContext ? '- Crie conexões com NPCs ou stakeholders existentes mencionados acima' : '- Defina aliados e rivais potenciais genéricos'}
- Conexão Primária (aliado/mentor/subordinado - NOME ESPECÍFICO)
- Conexão de Conflito (rival/inimigo/concorrente - NOME ESPECÍFICO)
- Dependência de Recurso (o que controla ou necessita)

═══════════════════════════════════════════════════════
6. STAT BLOCK SUGERIDO PARA ${systemRpg}:
═══════════════════════════════════════════════════════
${systemRpg === 'D&D 5e' ? `
- Nível/CR, Raça, Classe
- HP, AC, Velocidade
- Atributos: FOR, DES, CON, INT, SAB, CAR (valores numéricos)
- Proficiências principais
- Habilidades/Traços especiais (2-3 específicos)
- Ações de combate (se aplicável)
- Equipamento típico
` : systemRpg === 'Ordem Paranormal' ? `
- NEX (Exposição Paranormal)
- Classe (Combatente, Ocultista, etc)
- PV, PE, Defesa
- Atributos: FOR, AGI, INT, PRE, VIG (valores de 1-5)
- Perícias principais
- Poderes/Rituais (se tiver)
- Equipamento típico
` : `
- Nível de poder/desafio (1-10)
- Habilidade de combate (1-10)
- Habilidade social (1-10)
- Habilidades especiais (2-3 específicas para ${systemRpg})
- Equipamento típico
`}

═══════════════════════════════════════════════════════
7. PERFIL DE STAKEHOLDER:
═══════════════════════════════════════════════════════
- Poder (1-10): Influência política/militar/econômica
- Interesse (-10 a 10): Positivo = ajuda jogadores, Negativo = contra jogadores
- Arquétipo: Facilitador | Obstrutor | Oportunista | Recurso Chave
- Shadow File:
  * Segredo Operacional (algo que muda o jogo se descoberto)
  * Vulnerabilidade (ponto de alavancagem para manipulá-lo)
  * Agenda Oculta (objetivo secreto que contradiz aparência pública)

INTEGRAÇÃO NARRATIVA:
${useContext ? 'O personagem DEVE se encaixar organicamente nos arcos narrativos, ter relação direta com o antagonista principal ou stakeholders existentes.' : 'Crie um personagem independente, mas interessante e memorável.'}

Seja EXTREMAMENTE específico, dramático e detalhado. O mestre precisa poder INTERPRETAR este personagem com vida própria.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Nome completo' },
            role: { type: 'string', description: 'Cargo ou título' },
            physical_appearance: { type: 'string', description: 'Aparência física DETALHADA (mínimo 5 frases)' },
            personality: { type: 'string', description: 'Personalidade e maneirismos DETALHADOS (mínimo 5 frases)' },
            background: { type: 'string', description: 'Background e origem DETALHADOS (mínimo 5 frases)' },
            motivation: { type: 'string', description: 'Objetivo de curto prazo' },
            long_term_ambition: { type: 'string', description: 'Ambição de longo prazo' },
            core_values: { type: 'string', description: 'O que mais valoriza' },
            power: { type: 'integer', minimum: 1, maximum: 10, description: 'Poder na matriz' },
            interest: { type: 'integer', minimum: -10, maximum: 10, description: 'Interesse (negativo = contra jogadores)' },
            archetype: { type: 'string', description: 'Arquétipo operacional' },
            shadow_file: {
              type: 'object',
              properties: {
                operational_secret: { type: 'string', description: 'Segredo operacional' },
                vulnerability: { type: 'string', description: 'Ponto de alavancagem' },
                hidden_agenda: { type: 'string', description: 'Agenda oculta' }
              },
              required: ['operational_secret', 'vulnerability', 'hidden_agenda']
            },
            connections: {
              type: 'object',
              properties: {
                primary: { type: 'string', description: 'Aliado (nome específico)' },
                conflict: { type: 'string', description: 'Rival (nome específico)' },
                resource_dependency: { type: 'string', description: 'Recurso que controla/necessita' }
              },
              required: ['primary', 'conflict']
            },
            stat_block: {
              type: 'object',
              description: `Stat block para ${systemRpg}`,
              additionalProperties: true
            }
          },
          required: ['name', 'role', 'physical_appearance', 'personality', 'background', 'motivation', 'long_term_ambition', 'power', 'interest', 'archetype', 'shadow_file', 'connections', 'stat_block']
        }
      });

      const fullDescription = `**APARÊNCIA FÍSICA:**\n${result.physical_appearance}\n\n**PERSONALIDADE:**\n${result.personality}\n\n**BACKGROUND:**\n${result.background}\n\n**VALORES CENTRAIS:**\n${result.core_values || 'Não especificado'}`;

      const newNpc = await base44.entities.NpcCreature.create({
        campaign_id: campaignId,
        name: result.name,
        type: npcType,
        role: result.role || 'Personagem',
        motivation: result.motivation || 'Não especificada',
        description: fullDescription,
        stats_json: {
          power: result.power || 5,
          interest: result.interest || 0,
          archetype: result.archetype || archetype || '',
          long_term_ambition: result.long_term_ambition || '',
          shadow_file: result.shadow_file || {},
          connections: result.connections || {},
          stat_block: result.stat_block || {}
        }
      });

      if (onNpcCreated) {
        onNpcCreated(newNpc);
      }

      setOpen(false);
      setInstructions('');
      setArchetype('');
    } catch (error) {
      console.error('Erro ao gerar NPC:', error);
      alert('Erro ao gerar NPC. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-purple-600 hover:bg-purple-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Gerar Novo NPC
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-slate-900 border-purple-900/20 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Gerar Novo Personagem</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white mb-2 block">Tipo de Personagem</Label>
              <Select value={npcType} onValueChange={setNpcType}>
                <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NPC">NPC (Personagem Neutro)</SelectItem>
                  <SelectItem value="Ally">Aliado</SelectItem>
                  <SelectItem value="Villain">Vilão</SelectItem>
                  <SelectItem value="Monster">Monstro/Criatura</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white mb-2 block">Arquétipo Operacional (opcional)</Label>
              <Select value={archetype} onValueChange={setArchetype}>
                <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Nenhum (IA escolhe)</SelectItem>
                  <SelectItem value="Facilitador">Facilitador</SelectItem>
                  <SelectItem value="Obstrutor">Obstrutor</SelectItem>
                  <SelectItem value="Oportunista">Oportunista</SelectItem>
                  <SelectItem value="Recurso Chave">Recurso Chave</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2 p-4 bg-purple-900/10 border border-purple-500/20 rounded-lg">
            <Checkbox 
              id="useContext"
              checked={useContext}
              onCheckedChange={setUseContext}
              className="border-purple-500"
            />
            <div className="flex flex-col">
              <Label htmlFor="useContext" className="text-white font-semibold cursor-pointer">
                Usar Contexto da Campanha
              </Label>
              <p className="text-slate-400 text-xs mt-1">
                A IA criará o NPC baseado na WBS, SWOT do Antagonista e stakeholders existentes
              </p>
            </div>
          </div>

          <div>
            <Label className="text-white mb-2 block">
              Instruções Específicas (opcional)
            </Label>
            <Textarea
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Ex: Um diplomata veterano que perdeu sua família na guerra, agora busca vingança disfarçada de busca por paz..."
              className="min-h-[120px] bg-slate-950/50 border-slate-700 text-white"
            />
            <p className="text-slate-500 text-sm mt-2">
              Descreva características, personalidade, papel na história, ou deixe em branco para a IA criar livremente.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              className="border-slate-700 text-slate-300"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={loading}
              className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Gerar Personagem
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}