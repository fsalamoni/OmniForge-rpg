import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp, User, Heart, Sword, MessageCircle } from 'lucide-react';
import EditNpcDialog from './EditNpcDialog';
import NpcInteractionDialog from '../campaign-progression/NpcInteractionDialog';
import LinkedContent from '../shared/LinkedContent';
import AIExpander from '../shared/AIExpander';

export default function NpcCard({ npc, onUpdate, isOwner, campaignId, allNpcs = [], systemRpg = 'D&D 5e', campaignContext = '' }) {
  const [expanded, setExpanded] = useState(false);
  const [interactionDialogOpen, setInteractionDialogOpen] = useState(false);

  const typeColors = {
    NPC: 'bg-blue-600/20 text-blue-300 border-blue-500/30',
    Monster: 'bg-red-600/20 text-red-300 border-red-500/30',
    Ally: 'bg-green-600/20 text-green-300 border-green-500/30',
    Villain: 'bg-purple-600/20 text-purple-300 border-purple-500/30'
  };

  const typeIcons = {
    NPC: User,
    Monster: Sword,
    Ally: Heart,
    Villain: Sword
  };

  const Icon = typeIcons[npc.type] || User;

  return (
    <Card className="bg-slate-900/50 backdrop-blur-xl border-purple-900/20 hover:border-purple-500/50 transition-all">
      <CardHeader 
        className="cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className={`p-2 rounded-lg ${typeColors[npc.type]}`}>
                <Icon className="w-5 h-5" />
              </div>
              <CardTitle className="text-xl text-white">
                {npc.name}
              </CardTitle>
            </div>
            
            <Badge className={`${typeColors[npc.type]} border`}>
              {npc.type}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              onClick={(e) => {
                e.stopPropagation();
                setInteractionDialogOpen(true);
              }}
              size="sm"
              variant="ghost"
              className="text-purple-400 hover:text-purple-300"
              title="Conversar com NPC (IA)"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
            {isOwner && <EditNpcDialog npc={npc} onUpdate={onUpdate} />}
            {expanded ? (
              <ChevronUp className="w-5 h-5 text-slate-400 flex-shrink-0" />
            ) : (
              <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
            )}
          </div>
        </div>

        {npc.role && (
          <p className="text-sm text-purple-300 italic mt-2">
            {npc.role}
          </p>
        )}
      </CardHeader>

      {expanded && (
        <CardContent className="space-y-4">
          {npc.description && (
            <div>
              <h4 className="text-sm font-semibold text-slate-400 mb-1">Descrição</h4>
              <div className="text-sm leading-relaxed mb-3">
                <LinkedContent 
                  text={npc.description}
                  npcs={allNpcs.filter(n => n.id !== npc.id)}
                />
              </div>

              {/* Botão de Expansão com IA */}
              <AIExpander
                content={`NPC: ${npc.name}\nPapel: ${npc.role}\nDescrição: ${npc.description}\nMotivação: ${npc.motivation}`}
                context={campaignContext}
                expandType="npc"
                systemRpg={systemRpg}
              />
            </div>
          )}

          {npc.motivation && (
            <div>
              <h4 className="text-sm font-semibold text-slate-400 mb-1">Motivação</h4>
              <p className="text-slate-300 text-sm leading-relaxed">
                {npc.motivation}
              </p>
            </div>
          )}

          {npc.stats_json && Object.keys(npc.stats_json).length > 0 && (
            <div className="space-y-4">
              {/* Matriz de Poder/Interesse */}
              {(npc.stats_json.power || npc.stats_json.interest || npc.stats_json.archetype) && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 mb-2">Matriz de Influência</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {npc.stats_json.power && (
                      <div className="flex justify-between items-center bg-slate-950/50 p-2 rounded-lg">
                        <span className="text-xs text-slate-400 font-semibold">Poder</span>
                        <span className="text-sm text-amber-400 font-bold">{npc.stats_json.power}/10</span>
                      </div>
                    )}
                    {npc.stats_json.interest && (
                      <div className="flex justify-between items-center bg-slate-950/50 p-2 rounded-lg">
                        <span className="text-xs text-slate-400 font-semibold">Interesse</span>
                        <span className="text-sm text-amber-400 font-bold">{npc.stats_json.interest}/10</span>
                      </div>
                    )}
                  </div>
                  {npc.stats_json.archetype && (
                    <p className="text-xs text-purple-300 mt-2">
                      <span className="text-slate-400">Arquétipo:</span> {npc.stats_json.archetype}
                    </p>
                  )}
                </div>
              )}

              {/* Ambição de Longo Prazo */}
              {npc.stats_json.long_term_ambition && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 mb-1">Ambição</h4>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {npc.stats_json.long_term_ambition}
                  </p>
                </div>
              )}

              {/* Shadow File */}
              {npc.stats_json.shadow_file && (
                <div className="bg-red-900/10 border border-red-500/20 rounded-lg p-3 space-y-2">
                  <h4 className="text-sm font-semibold text-red-300 mb-2">Shadow File 🔒</h4>
                  {npc.stats_json.shadow_file.operational_secret && (
                    <div>
                      <span className="text-xs text-slate-400 font-semibold">Segredo:</span>
                      <p className="text-slate-300 text-sm">{npc.stats_json.shadow_file.operational_secret}</p>
                    </div>
                  )}
                  {npc.stats_json.shadow_file.vulnerability && (
                    <div>
                      <span className="text-xs text-slate-400 font-semibold">Vulnerabilidade:</span>
                      <p className="text-slate-300 text-sm">{npc.stats_json.shadow_file.vulnerability}</p>
                    </div>
                  )}
                  {npc.stats_json.shadow_file.hidden_agenda && (
                    <div>
                      <span className="text-xs text-slate-400 font-semibold">Agenda Oculta:</span>
                      <p className="text-slate-300 text-sm">{npc.stats_json.shadow_file.hidden_agenda}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Connections */}
              {npc.stats_json.connections && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 mb-2">Vínculos</h4>
                  <div className="space-y-2">
                    {npc.stats_json.connections.primary && (
                      <p className="text-sm text-slate-300">
                        <span className="text-green-400">✓ Aliado:</span> {npc.stats_json.connections.primary}
                      </p>
                    )}
                    {npc.stats_json.connections.conflict && (
                      <p className="text-sm text-slate-300">
                        <span className="text-red-400">✗ Rival:</span> {npc.stats_json.connections.conflict}
                      </p>
                    )}
                    {npc.stats_json.connections.resource_dependency && (
                      <p className="text-sm text-slate-300">
                        <span className="text-amber-400">⚡ Recurso:</span> {npc.stats_json.connections.resource_dependency}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Outros atributos */}
              {Object.entries(npc.stats_json).some(([key]) => 
                !['power', 'interest', 'archetype', 'long_term_ambition', 'shadow_file', 'connections'].includes(key)
              ) && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 mb-2">Outros Atributos</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(npc.stats_json)
                      .filter(([key]) => !['power', 'interest', 'archetype', 'long_term_ambition', 'shadow_file', 'connections'].includes(key))
                      .map(([stat, value]) => (
                        <div 
                          key={stat}
                          className="flex justify-between items-center bg-slate-950/50 p-2 rounded-lg"
                        >
                          <span className="text-xs text-slate-400 uppercase font-semibold">
                            {stat}
                          </span>
                          <span className="text-sm text-amber-400 font-bold">
                            {typeof value === 'object' ? JSON.stringify(value) : value}
                          </span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      )}

      <NpcInteractionDialog
        open={interactionDialogOpen}
        onOpenChange={setInteractionDialogOpen}
        npc={npc}
        campaignId={campaignId}
      />
    </Card>
  );
}