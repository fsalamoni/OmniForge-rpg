import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Target } from 'lucide-react';

export default function ArcCompletionTracker({ arc, isOwner }) {
  if (!isOwner) return null;

  const completedActs = arc.acts?.filter(act => act.completed).length || 0;
  const totalActs = arc.acts?.length || 0;
  
  const totalScenes = arc.acts?.reduce((sum, act) => sum + (act.scenes?.length || 0), 0) || 0;
  const completedScenes = arc.acts?.reduce((sum, act) => 
    sum + (act.scenes?.filter(scene => scene.completed).length || 0), 0
  ) || 0;
  
  const scenePercentage = totalScenes > 0 ? Math.round((completedScenes / totalScenes) * 100) : 0;
  const actPercentage = totalActs > 0 ? Math.round((completedActs / totalActs) * 100) : 0;

  return (
    <div className="bg-purple-900/10 border border-purple-500/20 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-purple-400" />
          <span className="text-white font-semibold">Progresso do Arco</span>
        </div>
        <div className="flex gap-2">
          <Badge className="bg-amber-600/20 text-amber-300 border-amber-500/30">
            {completedActs}/{totalActs} atos
          </Badge>
          <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/30">
            {completedScenes}/{totalScenes} cenas
          </Badge>
        </div>
      </div>
      
      <div className="space-y-2">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Atos</span>
            <span>{actPercentage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-amber-600 to-amber-400 h-2 rounded-full transition-all"
              style={{ width: `${actPercentage}%` }}
            />
          </div>
        </div>
        
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Cenas</span>
            <span>{scenePercentage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-600 to-blue-400 h-2 rounded-full transition-all"
              style={{ width: `${scenePercentage}%` }}
            />
          </div>
        </div>
      </div>
      
      {scenePercentage === 100 && (
        <div className="mt-3 flex items-center gap-2 text-green-400 text-sm">
          <CheckCircle2 className="w-4 h-4" />
          <span className="font-semibold">Arco Completo!</span>
        </div>
      )}
    </div>
  );
}