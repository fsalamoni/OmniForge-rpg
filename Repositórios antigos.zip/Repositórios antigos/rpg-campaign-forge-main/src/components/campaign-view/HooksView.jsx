import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Anchor, Sparkles } from 'lucide-react';
import AIExpander from '../shared/AIExpander';

export default function HooksView({ hooks, campaignContext = '', systemRpg = 'D&D 5e' }) {
  if (!hooks || hooks.length === 0) {
    return (
      <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
        <Anchor className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400">Nenhum gancho de aventura disponível</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Sparkles className="w-8 h-8 text-amber-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">Ganchos de Aventura</h2>
          <p className="text-slate-400">
            {hooks.length} {hooks.length === 1 ? 'gancho disponível' : 'ganchos disponíveis'} para iniciar a aventura
          </p>
        </div>
      </div>

      <div className="grid gap-4">
        {hooks.map((hook, index) => {
          const isString = typeof hook === 'string';
          const hookText = isString ? hook : (hook.description || '');
          
          return (
            <Card key={index} className="bg-slate-900/50 backdrop-blur-xl border-amber-900/20 hover:border-amber-500/50 transition-all">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-amber-600/20 border border-amber-500/30">
                    <Anchor className="w-5 h-5 text-amber-400" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl text-white mb-1">
                      {isString ? `Gancho ${index + 1}` : (hook.title || `Gancho ${index + 1}`)}
                    </CardTitle>
                    <span className="text-sm text-amber-400">Porta de entrada #{index + 1}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 leading-relaxed whitespace-pre-wrap mb-4">
                  {hookText}
                </p>

                <AIExpander
                  content={`Gancho ${index + 1}: ${hookText}`}
                  context={campaignContext}
                  expandType="general"
                  systemRpg={systemRpg}
                />
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="p-6 bg-blue-900/10 border border-blue-500/20 rounded-lg">
        <h3 className="text-blue-300 font-semibold mb-2 flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          Dica para o Narrador
        </h3>
        <p className="text-slate-400 text-sm leading-relaxed">
          Cada gancho oferece uma porta de entrada diferente para a campanha. Escolha o que melhor
          se encaixa com o background dos personagens dos seus jogadores, ou deixe que eles escolham
          qual situação os atrai mais. Você também pode usar múltiplos ganchos para diferentes
          grupos de personagens que se encontram durante a aventura.
        </p>
      </div>
    </div>
  );
}