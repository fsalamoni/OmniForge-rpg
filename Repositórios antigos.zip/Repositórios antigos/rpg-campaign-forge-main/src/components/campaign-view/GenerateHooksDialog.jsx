import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles } from 'lucide-react';

export default function GenerateHooksDialog({ campaignId, campaign, onHooksGenerated }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [quantity, setQuantity] = useState(5);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      // Buscar respostas 5W2H
      const steps = await base44.entities.CampaignStep.filter({ campaign_id: campaignId });
      const answersText = steps
        .sort((a, b) => a.order_index - b.order_index)
        .map(s => `${s.question_text}: ${s.user_answer}`)
        .join('\n');

      const description = campaign.content_json?.campaign_description || {};

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Crie ${quantity} ganchos de aventura únicos e criativos.

INFORMAÇÕES DA CAMPANHA:
Sistema: ${campaign.system_rpg}
Ambientação: ${campaign.setting}
Duração: ${campaign.duration_type}

RESPOSTAS 5W2H:
${answersText}

DESCRIÇÃO:
Introdução: ${description.introduction || ''}
Contexto: ${description.world_context || ''}
Conflito: ${description.central_conflict || ''}

CADA GANCHO DEVE TER:
- 6-8 frases completas
- Situação inicial clara (onde os jogadores começam)
- Evento gatilho (o que acontece)
- Urgência (por que agir agora)
- Isca (motivação dos jogadores)
- Conexão clara com o conflito central

Seja ESPECÍFICO e CRIATIVO. Cada gancho deve ser DIFERENTE dos outros.`,
        response_json_schema: {
          type: 'object',
          properties: {
            plot_hooks: {
              type: 'array',
              items: { type: 'string' },
              minItems: quantity,
              maxItems: quantity
            }
          },
          required: ['plot_hooks']
        }
      });

      // Atualizar campanha
      const content = campaign.content_json || {};
      await base44.entities.Campaign.update(campaignId, {
        content_json: {
          ...content,
          plot_hooks: result.plot_hooks
        }
      });

      onHooksGenerated();
      setOpen(false);
    } catch (error) {
      console.error('Erro ao gerar ganchos:', error);
      alert('Erro ao gerar ganchos: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-purple-600 hover:bg-purple-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Gerar Ganchos
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-slate-900 border-purple-900/30 text-white">
        <DialogHeader>
          <DialogTitle>Gerar Ganchos de Aventura</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Quantidade de Ganchos (3-10)</Label>
            <input
              type="range"
              min="3"
              max="10"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value))}
              className="w-full mt-2"
            />
            <div className="text-center text-purple-400 font-bold text-2xl mt-2">
              {quantity}
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Gerando...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Gerar {quantity} Ganchos
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}