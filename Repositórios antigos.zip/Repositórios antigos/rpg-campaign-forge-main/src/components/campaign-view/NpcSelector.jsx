import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function NpcSelector({ campaignId, description, hooks, arcs, systemRpg, onNpcsCreated }) {
  const [npcsFromContent, setNpcsFromContent] = useState([]);
  const [selectedNpcs, setSelectedNpcs] = useState({});
  const [generating, setGenerating] = useState(false);
  const [extracting, setExtracting] = useState(false);

  useEffect(() => {
    extractNpcs();
  }, [description, hooks, arcs]);

  const extractNpcs = async () => {
    setExtracting(true);
    try {
      const contentText = `
DESCRIÇÃO: ${description}

GANCHOS: ${hooks?.map((h, i) => `\n${i + 1}. ${h}`).join('')}

ARCOS: ${arcs?.map(arc => `
Arco: ${arc.name}
NPCs: ${arc.acts?.map(act => act.npcs_involved?.join(', ')).join(', ')}
`).join('\n')}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Extraia TODOS os NPCs e monstros mencionados no conteúdo abaixo.

${contentText}

Para cada NPC/monstro, identifique:
- name: Nome exato mencionado
- locations: Lista de locais/momentos onde aparece (ex: "Gancho 2", "Arco 1 - Ato 2", "Descrição inicial")
- role: Papel na história (ex: "Aliado", "Vilão", "Informante", "Monstro")

Retorne TODOS mencionados, sem exceção.`,
        response_json_schema: {
          type: 'object',
          properties: {
            npcs: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  locations: { type: 'array', items: { type: 'string' } },
                  role: { type: 'string' }
                }
              }
            }
          }
        }
      });

      setNpcsFromContent(result.npcs || []);
    } catch (error) {
      console.error('Erro ao extrair NPCs:', error);
    } finally {
      setExtracting(false);
    }
  };

  const handleToggleNpc = (npcName) => {
    setSelectedNpcs(prev => ({
      ...prev,
      [npcName]: !prev[npcName]
    }));
  };

  const handleGenerateSelected = async () => {
    const selected = npcsFromContent.filter(npc => selectedNpcs[npc.name]);
    if (selected.length === 0) {
      alert('Selecione pelo menos um NPC');
      return;
    }

    setGenerating(true);
    try {
      const promises = selected.map(async (npc) => {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Crie um NPC completo para ${systemRpg}.

NOME: ${npc.name}
PAPEL: ${npc.role}
APARECE EM: ${npc.locations.join(', ')}

DESCRIÇÃO: ${description.substring(0, 500)}

CRIE:
- description: Descrição física e personalidade (10-15 frases)
- motivation: Motivação profunda (4-5 frases)
- background_hook: Gancho narrativo pessoal (3-4 frases)
- relationships: Lista de 2-3 relacionamentos com outros NPCs
- stats: Estatísticas para ${systemRpg}`,
          response_json_schema: {
            type: 'object',
            properties: {
              description: { type: 'string' },
              motivation: { type: 'string' },
              background_hook: { type: 'string' },
              relationships: { type: 'array', items: { type: 'object' } },
              stats: { type: 'object' }
            }
          }
        });

        return base44.entities.NpcCreature.create({
          campaign_id: campaignId,
          name: npc.name,
          type: npc.role.includes('Vilão') ? 'Villain' : npc.role.includes('Aliado') ? 'Ally' : npc.role.includes('Monstro') ? 'Monster' : 'NPC',
          role: npc.role,
          motivation: result.motivation,
          description: result.description,
          stats_json: {
            ...result.stats,
            background_hook: result.background_hook,
            relationships: result.relationships,
            appears_in: npc.locations
          }
        });
      });

      await Promise.all(promises);
      alert(`${selected.length} NPCs criados com sucesso!`);
      if (onNpcsCreated) {
        onNpcsCreated();
      }
      setSelectedNpcs({});
    } catch (error) {
      console.error('Erro ao gerar NPCs:', error);
      alert('Erro ao gerar NPCs: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const groupedNpcs = npcsFromContent.reduce((acc, npc) => {
    npc.locations.forEach(loc => {
      if (!acc[loc]) acc[loc] = [];
      acc[loc].push(npc);
    });
    return acc;
  }, {});

  if (extracting) {
    return (
      <div className="text-center py-12">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
        <p className="text-slate-400">Extraindo NPCs do conteúdo...</p>
      </div>
    );
  }

  if (npcsFromContent.length === 0) {
    return (
      <div className="text-center py-12 bg-slate-900/30 rounded-lg border border-slate-800">
        <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400">Nenhum NPC encontrado na descrição, ganchos ou arcos</p>
        <p className="text-slate-500 text-sm mt-2">Crie ganchos e arcos primeiro</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/50 backdrop-blur-xl border-purple-900/20">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-white">
              <Users className="w-6 h-6 text-purple-400" />
              NPCs Encontrados ({npcsFromContent.length})
            </span>
            <Button
              onClick={handleGenerateSelected}
              disabled={generating || Object.values(selectedNpcs).filter(Boolean).length === 0}
              className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600"
            >
              {generating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Criando...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Criar {Object.values(selectedNpcs).filter(Boolean).length} Selecionados
                </>
              )}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400 text-sm mb-4">
            Selecione os NPCs que deseja criar com detalhes completos (stats, motivações, relacionamentos)
          </p>
        </CardContent>
      </Card>

      {Object.entries(groupedNpcs).map(([location, npcs]) => (
        <Card key={location} className="bg-slate-900/50 backdrop-blur-xl border-slate-700">
          <CardHeader>
            <CardTitle className="text-lg text-white">{location}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {npcs.map(npc => (
              <div
                key={npc.name + location}
                className="flex items-center gap-3 p-3 bg-slate-950/50 rounded-lg border border-slate-700 hover:border-purple-500/50 transition-colors"
              >
                <Checkbox
                  checked={selectedNpcs[npc.name] || false}
                  onCheckedChange={() => handleToggleNpc(npc.name)}
                />
                <div className="flex-1">
                  <p className="text-white font-medium">{npc.name}</p>
                  <p className="text-slate-400 text-sm">{npc.role}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}