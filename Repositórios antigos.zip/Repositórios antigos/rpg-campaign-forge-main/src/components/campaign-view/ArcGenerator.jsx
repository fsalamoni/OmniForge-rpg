import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ArcGenerator({ campaignId, description, answers5W2H, systemRpg, setting, onArcGenerated }) {
  const [arcName, setArcName] = useState('');
  const [missionType, setMissionType] = useState('investigação');
  const [numActs, setNumActs] = useState(3);
  const [scenesPerAct, setScenesPerAct] = useState(2);
  const [customInstructions, setCustomInstructions] = useState('');
  const [generating, setGenerating] = useState(false);

  const missionTypes = [
    'Investigação',
    'Exploração',
    'Roubo',
    'Assassinato',
    'Resgate',
    'Diplomacia',
    'Infiltração',
    'Defesa',
    'Conquista',
    'Mistério',
    'Sobrevivência',
    'Caça',
    'Escolta'
  ];

  const handleGenerate = async () => {
    if (!arcName.trim()) {
      alert('Por favor, defina um nome para o arco');
      return;
    }

    setGenerating(true);
    try {
      console.log('🤖 Iniciando geração do arco com IA...');
      console.log('📊 Parâmetros:', { arcName, missionType, numActs, scenesPerAct });
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `TAREFA: Criar arco de RPG com EXATAMENTE ${numActs} atos, cada ato com EXATAMENTE ${scenesPerAct} cenas.

Nome: ${arcName}
Missão: ${missionType}
Sistema: ${systemRpg}
Ambientação: ${setting}

REGRA ABSOLUTA: Total de ${numActs} atos × ${scenesPerAct} cenas = ${numActs * scenesPerAct} cenas no arco completo.

Estrutura JSON obrigatória:
{
  "name": "${arcName}",
  "arc_objective": "objetivo principal do arco",
  "world_change": "mudança que acontece no mundo",
  "arc_villain": "antagonista principal",
  "description": "resumo geral do arco",
  "acts": [
    // ${numActs} objetos aqui, cada um com ${scenesPerAct} cenas
  ]
}

Cada ato DEVE ter:
- title (string)
- act_function (string: setup/rising_action/climax/falling_action)
- description (string)
- objectives (array de 3 strings)
- npcs_involved (array de strings)
- scenes (array de EXATAMENTE ${scenesPerAct} objetos)

Cada cena DEVE ter todos esses campos:
- scene_name, scene_type, trigger, read_aloud, hidden_reality, objective
- secrets_and_clues (array), suggested_checks (array), outcomes (array)
- opposition_passive, opposition_active, exits, rewards

${customInstructions ? `EXTRA: ${customInstructions}\n` : ''}
Contexto: ${description.substring(0, 600)}`,
        response_json_schema: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            arc_objective: { type: 'string' },
            world_change: { type: 'string' },
            arc_villain: { type: 'string' },
            description: { type: 'string' },
            acts: {
              type: 'array',
              minItems: numActs,
              maxItems: numActs,
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  act_function: { type: 'string' },
                  description: { type: 'string' },
                  objectives: { type: 'array', items: { type: 'string' } },
                  twist: { type: 'string' },
                  npcs_involved: { type: 'array', items: { type: 'string' } },
                  scenes: {
                    type: 'array',
                    minItems: scenesPerAct,
                    maxItems: scenesPerAct,
                    items: {
                      type: 'object',
                      properties: {
                        scene_name: { type: 'string' },
                        scene_type: { type: 'string' },
                        trigger: { type: 'string' },
                        read_aloud: { type: 'string' },
                        hidden_reality: { type: 'string' },
                        secrets_and_clues: { 
                          type: 'array', 
                          items: { 
                            type: 'object',
                            properties: {
                              clue: { type: 'string' },
                              how_to_find: { type: 'string' }
                            }
                          } 
                        },
                        objective: { type: 'string' },
                        opposition_passive: { type: 'string' },
                        opposition_active: { type: 'string' },
                        suggested_checks: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              skill: { type: 'string' },
                              dc: { type: 'string' },
                              on_success: { type: 'string' },
                              on_failure: { type: 'string' }
                            }
                          }
                        },
                        outcomes: { type: 'array', items: { type: 'string' } },
                        exits: { type: 'string' },
                        rewards: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          },
          required: ['name', 'acts']
        }
      });

      console.log('✅ Resposta da IA recebida');
      console.log('📦 Estrutura recebida:', {
        temName: !!result?.name,
        temActs: !!result?.acts,
        numAtos: result?.acts?.length,
        acts: result?.acts?.map((act, i) => ({
          index: i,
          title: act?.title,
          numScenes: act?.scenes?.length
        }))
      });
      
      // VALIDAÇÕES CRÍTICAS
      if (!result || !result.name) {
        throw new Error('IA retornou um arco sem nome');
      }
      
      if (!result.acts || !Array.isArray(result.acts) || result.acts.length === 0) {
        throw new Error('IA não criou nenhum ato para o arco');
      }

      // VALIDAR QUANTIDADE DE ATOS
      if (result.acts.length !== numActs) {
        throw new Error(`IA criou ${result.acts.length} atos, mas você pediu ${numActs} atos. Por favor, gere novamente.`);
      }

      // VALIDAR CENAS POR ATO
      for (let i = 0; i < result.acts.length; i++) {
        const act = result.acts[i];
        if (!act.scenes || act.scenes.length !== scenesPerAct) {
          throw new Error(`Ato ${i + 1} ("${act.title}") tem ${act.scenes?.length || 0} cenas, mas você pediu ${scenesPerAct} cenas por ato. Por favor, gere novamente.`);
        }
      }

      console.log('✅ Validação passou - estrutura correta!');
      await onArcGenerated(result);
      
      // Resetar form
      setArcName('');
      setCustomInstructions('');
      setMissionType('investigação');
      setNumActs(3);
      setScenesPerAct(2);
    } catch (error) {
      console.error('Erro ao gerar arco:', error);
      alert('Erro ao gerar arco: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Card className="bg-slate-900/50 backdrop-blur-xl border-purple-900/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Sparkles className="w-6 h-6 text-purple-400" />
          Criar Novo Arco Narrativo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-slate-300">Nome do Arco *</Label>
          <Input
            value={arcName}
            onChange={(e) => setArcName(e.target.value)}
            placeholder="Ex: O Segredo das Ruínas Antigas"
            className="bg-slate-950/50 border-slate-700 text-white mt-2"
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label className="text-slate-300">Tipo de Missão</Label>
            <Select value={missionType} onValueChange={setMissionType}>
              <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {missionTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-slate-300">Número de Atos</Label>
            <Input
              type="number"
              min="2"
              max="6"
              value={numActs}
              onChange={(e) => setNumActs(parseInt(e.target.value))}
              className="bg-slate-950/50 border-slate-700 text-white mt-2"
            />
          </div>

          <div>
            <Label className="text-slate-300">Cenas por Ato</Label>
            <Input
              type="number"
              min="1"
              max="5"
              value={scenesPerAct}
              onChange={(e) => setScenesPerAct(parseInt(e.target.value))}
              className="bg-slate-950/50 border-slate-700 text-white mt-2"
            />
          </div>
        </div>

        <div>
          <Label className="text-slate-300">Instruções Específicas (Opcional)</Label>
          <Textarea
            value={customInstructions}
            onChange={(e) => setCustomInstructions(e.target.value)}
            placeholder="Ex: Incluir elementos de horror, focar em dilemas morais..."
            className="bg-slate-950/50 border-slate-700 text-white mt-2 min-h-[100px]"
          />
        </div>

        <Button
          onClick={handleGenerate}
          disabled={generating || !arcName.trim()}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600"
        >
          {generating ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Gerando arco...
            </>
          ) : (
            <>
              <BookOpen className="w-5 h-5 mr-2" />
              Gerar Arco: {arcName || 'Defina um nome'}
            </>
          )}
        </Button>

        <p className="text-xs text-slate-500 text-center">
          Será gerado: {numActs} atos × {scenesPerAct} cenas = {numActs * scenesPerAct} cenas totais
        </p>
      </CardContent>
    </Card>
  );
}