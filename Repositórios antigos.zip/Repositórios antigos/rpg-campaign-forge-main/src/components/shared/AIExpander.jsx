import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2, ChevronDown, ChevronUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';

/**
 * AIExpander - Botão "Expandir com IA" para gerar mais detalhes sobre um conteúdo
 */
export default function AIExpander({ 
  content, 
  context, 
  expandType = 'general', 
  systemRpg = 'D&D 5e',
  onExpanded 
}) {
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [expandedContent, setExpandedContent] = useState('');

  const getPromptByType = () => {
    switch (expandType) {
      case 'npc':
        return `Você é um mestre de RPG especialista em ${systemRpg}. Expanda e aprofunde os DETALHES deste NPC:

${content}

CONTEXTO DA CAMPANHA:
${context}

Gere MAIS DETALHES sobre este NPC em 3 áreas (mínimo 4-5 sentenças CADA):

1. HISTÓRICO DETALHADO: Infância, eventos formativos, relacionamentos passados, como chegou onde está
2. PERSONALIDADE PROFUNDA: Medos secretos, desejos ocultos, contradições internas, como age em diferentes situações
3. HOOKS DE INTERAÇÃO: 3-4 formas específicas que os jogadores podem interagir com este NPC, com possíveis resultados

Seja ESPECÍFICO e CINEMATOGRÁFICO. Use as regras de ${systemRpg}.`;

      case 'challenge':
        return `Você é um mestre de RPG especialista em ${systemRpg}. Expanda e detalhe este DESAFIO:

${content}

CONTEXTO DA CAMPANHA:
${context}

Forneça DETALHES TÁTICOS e MECÂNICOS completos (use regras de ${systemRpg}):

1. DESCRIÇÃO SENSORIAL (3-4 sentenças): Como a cena se parece, sons, cheiros, atmosfera
2. MECÂNICAS DETALHADAS: DCs específicas, stats de inimigos, condições especiais, regras aplicáveis
3. MÚLTIPLAS SOLUÇÕES: 3-4 abordagens diferentes que os jogadores podem usar (combate, social, furtividade, criativa)
4. CONSEQUÊNCIAS RAMIFICADAS: O que acontece em caso de sucesso total, sucesso parcial, falha

Seja ESPECÍFICO com números, estatísticas e regras de ${systemRpg}.`;

      case 'act':
        return `Você é um mestre de RPG especialista em ${systemRpg}. Expanda este ATO com mais cenas e detalhes:

${content}

CONTEXTO DA CAMPANHA:
${context}

Gere CONTEÚDO ADICIONAL para este ato:

1. CENAS INTERMEDIÁRIAS: 2-3 cenas menores que podem acontecer neste ato
2. DIÁLOGOS SUGERIDOS: 2-3 diálogos-chave com NPCs importantes
3. PISTAS ADICIONAIS: 2-3 pistas extras que podem ser descobertas
4. EVENTOS ALEATÓRIOS: 2 eventos que podem acontecer durante este ato para surpreender os jogadores

Use as regras e atmosfera de ${systemRpg}.`;

      case 'arc':
        return `Você é um mestre de RPG especialista em ${systemRpg}. Expanda este ARCO NARRATIVO:

${content}

CONTEXTO DA CAMPANHA:
${context}

Gere MATERIAL ADICIONAL para este arco:

1. SUB-TRAMAS: 2 sub-tramas que podem se desenrolar paralelamente ao arco principal
2. NPCS SECUNDÁRIOS: 2-3 NPCs menores mas memoráveis que aparecem neste arco
3. LOCAIS IMPORTANTES: 3-4 locais-chave com descrições sensoriais
4. TWISTS POTENCIAIS: 2-3 reviravoltas que podem acontecer dependendo das escolhas dos jogadores

Seja DETALHADO e use as regras de ${systemRpg}.`;

      default:
        return `Você é um mestre de RPG especialista em ${systemRpg}. Expanda e detalhe o seguinte conteúdo:

${content}

CONTEXTO DA CAMPANHA:
${context}

Forneça MAIS DETALHES, EXEMPLOS CONCRETOS e ELEMENTOS JOGÁVEIS. Seja específico e use as regras de ${systemRpg}.`;
    }
  };

  const handleExpand = async () => {
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: getPromptByType()
      });

      setExpandedContent(result);
      setExpanded(true);
      
      if (onExpanded) {
        onExpanded(result);
      }
    } catch (error) {
      console.error('Erro ao expandir com IA:', error);
      alert('Erro ao gerar conteúdo adicional. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      <Button
        onClick={handleExpand}
        disabled={loading}
        variant="outline"
        size="sm"
        className="border-purple-500/30 text-purple-300 hover:bg-purple-900/20"
      >
        {loading ? (
          <>
            <Loader2 className="w-3 h-3 mr-2 animate-spin" />
            Gerando...
          </>
        ) : (
          <>
            <Sparkles className="w-3 h-3 mr-2" />
            Expandir com IA
          </>
        )}
      </Button>

      {expanded && expandedContent && (
        <div className="mt-4 p-4 bg-purple-900/10 border border-purple-500/20 rounded-lg space-y-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-purple-300 font-semibold text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Conteúdo Expandido pela IA
            </span>
            <button
              onClick={() => setExpanded(false)}
              className="text-slate-400 hover:text-white"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
          <p className="text-slate-300 text-sm whitespace-pre-wrap leading-relaxed">
            {expandedContent}
          </p>
        </div>
      )}
    </div>
  );
}