import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Users, Lightbulb, Target } from 'lucide-react';

/**
 * LinkedContent - Renderiza texto com links automáticos para NPCs, Pistas e Objetivos
 * Quando clicado, abre um dialog com detalhes completos
 */
export default function LinkedContent({ text, npcs = [], clues = [], objectives = [] }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogContent, setDialogContent] = useState(null);

  if (!text) return null;

  // Criar mapa de entidades para busca rápida
  const entityMap = new Map();
  
  npcs.forEach(npc => {
    if (npc?.name) {
      entityMap.set(npc.name.toLowerCase(), {
        type: 'npc',
        name: npc.name,
        data: npc
      });
    }
  });

  // Função para identificar e linkar entidades no texto
  const renderLinkedText = () => {
    let processedText = text;
    const links = [];

    // Encontrar todas as correspondências de NPCs
    entityMap.forEach((entity, key) => {
      const regex = new RegExp(`\\b${key}\\b`, 'gi');
      const matches = [...processedText.matchAll(regex)];
      
      matches.forEach(match => {
        links.push({
          index: match.index,
          length: match[0].length,
          text: match[0],
          entity: entity
        });
      });
    });

    // Ordenar links por posição (último primeiro para não quebrar índices)
    links.sort((a, b) => b.index - a.index);

    // Substituir por componentes clicáveis
    const parts = [];
    let lastIndex = processedText.length;

    links.forEach(link => {
      // Texto depois do link
      parts.unshift(processedText.substring(link.index + link.length, lastIndex));
      
      // Link clicável
      parts.unshift(
        <button
          key={link.index}
          onClick={() => {
            setDialogContent(link.entity);
            setDialogOpen(true);
          }}
          className="text-purple-400 hover:text-purple-300 underline decoration-dotted cursor-pointer font-semibold"
        >
          {link.text}
        </button>
      );
      
      lastIndex = link.index;
    });

    // Texto antes do primeiro link
    parts.unshift(processedText.substring(0, lastIndex));

    return parts;
  };

  const renderDialog = () => {
    if (!dialogContent) return null;

    if (dialogContent.type === 'npc') {
      const npc = dialogContent.data;
      const stats = npc.stats_json || {};

      return (
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-slate-900 border-purple-900/50">
          <DialogHeader>
            <DialogTitle className="text-2xl text-white flex items-center gap-2">
              <Users className="w-6 h-6 text-purple-400" />
              {npc.name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Tipo e Papel */}
            <div className="flex gap-2">
              <Badge className="bg-purple-600/20 text-purple-300">
                {npc.type}
              </Badge>
              <Badge variant="outline" className="border-slate-700 text-slate-300">
                {npc.role}
              </Badge>
            </div>

            {/* Descrição */}
            <div>
              <h3 className="text-white font-semibold mb-2">Descrição</h3>
              <p className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                {npc.description}
              </p>
            </div>

            {/* Motivação */}
            {npc.motivation && (
              <div>
                <h3 className="text-white font-semibold mb-2">Motivação</h3>
                <p className="text-slate-300">{npc.motivation}</p>
              </div>
            )}

            {/* Stats da Matriz */}
            {(stats.power !== undefined || stats.interest !== undefined) && (
              <div className="grid grid-cols-2 gap-4">
                {stats.power !== undefined && (
                  <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-700">
                    <span className="text-slate-400 text-sm">Poder</span>
                    <p className="text-white font-bold text-xl">{stats.power}/10</p>
                  </div>
                )}
                {stats.interest !== undefined && (
                  <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-700">
                    <span className="text-slate-400 text-sm">Interesse</span>
                    <p className="text-white font-bold text-xl">{stats.interest > 0 ? '+' : ''}{stats.interest}/10</p>
                  </div>
                )}
              </div>
            )}

            {/* Shadow File */}
            {stats.shadow_file && (
              <div className="p-4 bg-amber-900/10 border border-amber-500/20 rounded-lg">
                <h3 className="text-amber-300 font-semibold mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Arquivo Secreto
                </h3>
                <div className="space-y-2 text-sm">
                  {stats.shadow_file.operational_secret && (
                    <p className="text-slate-300">
                      <span className="text-amber-400 font-semibold">Segredo:</span> {stats.shadow_file.operational_secret}
                    </p>
                  )}
                  {stats.shadow_file.vulnerability && (
                    <p className="text-slate-300">
                      <span className="text-amber-400 font-semibold">Vulnerabilidade:</span> {stats.shadow_file.vulnerability}
                    </p>
                  )}
                  {stats.shadow_file.hidden_agenda && (
                    <p className="text-slate-300">
                      <span className="text-amber-400 font-semibold">Agenda Oculta:</span> {stats.shadow_file.hidden_agenda}
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      );
    }

    return null;
  };

  return (
    <>
      <div className="text-slate-300 leading-relaxed whitespace-pre-wrap">
        {renderLinkedText()}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        {renderDialog()}
      </Dialog>
    </>
  );
}