import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Zap, AlertTriangle, Edit } from 'lucide-react';
import EditSwotDialog from './EditSwotDialog';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';

export default function SwotView({ swot, isOwner, campaignId }) {
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const handleSaveSwot = async (updatedSwot) => {
    const campaigns = await base44.entities.Campaign.list();
    const campaign = campaigns.find(c => c.id === campaignId);
    await base44.entities.Campaign.update(campaignId, {
      content_json: {
        ...campaign.content_json,
        antagonist_swot: updatedSwot
      }
    });
    queryClient.invalidateQueries(['campaign', campaignId]);
  };
  if (!swot || !swot.name) {
    return (
      <div className="text-center py-8 text-slate-400">
        Análise SWOT não disponível para esta campanha
      </div>
    );
  }

  const sections = [
    {
      title: 'Forças',
      key: 'strengths',
      icon: TrendingUp,
      color: 'green',
      bgColor: 'bg-green-900/10',
      borderColor: 'border-green-500/30',
      textColor: 'text-green-300'
    },
    {
      title: 'Fraquezas',
      key: 'weaknesses',
      icon: TrendingDown,
      color: 'red',
      bgColor: 'bg-red-900/10',
      borderColor: 'border-red-500/30',
      textColor: 'text-red-300'
    },
    {
      title: 'Oportunidades',
      key: 'opportunities',
      icon: Zap,
      color: 'amber',
      bgColor: 'bg-amber-900/10',
      borderColor: 'border-amber-500/30',
      textColor: 'text-amber-300'
    },
    {
      title: 'Ameaças',
      key: 'threats',
      icon: AlertTriangle,
      color: 'purple',
      bgColor: 'bg-purple-900/10',
      borderColor: 'border-purple-500/30',
      textColor: 'text-purple-300'
    }
  ];

  return (
    <>
      <div className="space-y-6">
        {isOwner && (
          <div className="flex justify-end">
            <Button onClick={() => setEditDialogOpen(true)} size="sm" variant="outline" className="border-red-500/30">
              <Edit className="w-4 h-4 mr-2" />
              Editar SWOT
            </Button>
          </div>
        )}

        {/* Antagonist Header */}
        <Card className="bg-gradient-to-br from-red-900/30 to-slate-900/30 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-white text-2xl flex items-center gap-3">
              <span className="text-4xl">👹</span>
              Perfil Estratégico: {swot.name}
            </CardTitle>
            <p className="text-slate-400">
              Análise SWOT do Antagonista Principal
            </p>
          </CardHeader>
        </Card>

      {/* SWOT Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {sections.map((section) => {
          const Icon = section.icon;
          const items = swot[section.key] || [];
          
          return (
            <Card 
              key={section.key}
              className={`${section.bgColor} border ${section.borderColor}`}
            >
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Icon className={`w-6 h-6 ${section.textColor}`} />
                  <CardTitle className={`${section.textColor} text-xl`}>
                    {section.title}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {items.length === 0 ? (
                  <p className="text-slate-500 italic">Nenhum item definido</p>
                ) : (
                  <ul className="space-y-2">
                    {items.map((item, index) => (
                      <li 
                        key={index}
                        className="flex items-start gap-2 text-slate-300"
                      >
                        <span className="text-slate-500 mt-1">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Strategic Insights */}
      <Card className="bg-slate-900/50 border-purple-900/20">
        <CardHeader>
          <CardTitle className="text-white">Insights Estratégicos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="p-3 bg-green-900/10 border border-green-500/20 rounded-lg">
            <p className="text-green-300 font-semibold mb-1">Pontos de Força do Vilão:</p>
            <p className="text-slate-300">
              Os jogadores devem evitar confronto direto. Utilize as fraquezas para criar planos de infiltração.
            </p>
          </div>
          <div className="p-3 bg-red-900/10 border border-red-500/20 rounded-lg">
            <p className="text-red-300 font-semibold mb-1">Vulnerabilidades Exploráveis:</p>
            <p className="text-slate-300">
              Cada fraqueza é um gancho de aventura. Se os jogadores descobrem uma vulnerabilidade, 
              podem criar planos para neutralizar o antagonista.
            </p>
          </div>
        </CardContent>
      </Card>
      </div>

      {isOwner && (
        <EditSwotDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          swot={swot}
          onSave={handleSaveSwot}
        />
      )}
    </>
  );
}