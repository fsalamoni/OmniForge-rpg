import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, TrendingUp, Target } from 'lucide-react';

export default function StakeholdersMatrix({ stakeholders, isOwner }) {
  if (!stakeholders || stakeholders.length === 0) {
    return (
      <div className="text-center py-8 text-slate-400">
        Matriz de Stakeholders não disponível
      </div>
    );
  }

  // Categorizar stakeholders
  const categorizeStakeholder = (power, interest) => {
    if (power >= 7 && interest >= 5) return { label: 'Gerenciar de Perto', color: 'red' };
    if (power >= 7 && interest < 5) return { label: 'Manter Satisfeitos', color: 'amber' };
    if (power < 7 && interest >= 5) return { label: 'Manter Informados', color: 'blue' };
    return { label: 'Monitorar', color: 'slate' };
  };

  const getPositionStyle = (power, interest) => {
    // Calcular posição no grid (0-100%)
    const x = ((interest + 10) / 20) * 100; // -10 to 10 => 0 to 100%
    const y = 100 - ((power - 1) / 9) * 100; // 1 to 10 => 100 to 0% (inverted)
    
    return {
      left: `${x}%`,
      top: `${y}%`
    };
  };

  return (
    <div className="space-y-6">
      {/* Matriz Visual */}
      <Card className="bg-slate-900/50 border-purple-900/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-purple-400" />
            Matriz de Poder x Interesse
          </CardTitle>
          <p className="text-slate-400 text-sm">
            Posicionamento estratégico dos stakeholders na campanha
          </p>
        </CardHeader>
        <CardContent>
          {/* Grid Container */}
          <div className="relative w-full h-96 bg-gradient-to-br from-slate-950 to-slate-900 rounded-lg border border-slate-700">
            {/* Eixos */}
            <div className="absolute bottom-0 left-0 w-full h-px bg-slate-600" />
            <div className="absolute left-1/2 top-0 w-px h-full bg-slate-600" />
            
            {/* Labels dos Eixos */}
            <div className="absolute -left-20 top-1/2 -translate-y-1/2 -rotate-90 text-slate-400 text-sm font-semibold">
              PODER →
            </div>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-slate-400 text-sm font-semibold">
              ← NEGATIVO | INTERESSE | POSITIVO →
            </div>

            {/* Quadrantes */}
            <div className="absolute top-2 left-2 text-xs text-red-400 font-semibold">
              Gerenciar de Perto
            </div>
            <div className="absolute top-2 right-2 text-xs text-amber-400 font-semibold">
              Manter Satisfeitos
            </div>
            <div className="absolute bottom-8 left-2 text-xs text-blue-400 font-semibold">
              Manter Informados
            </div>
            <div className="absolute bottom-8 right-2 text-xs text-slate-500 font-semibold">
              Monitorar
            </div>

            {/* Stakeholders */}
            {stakeholders.map((stakeholder, index) => {
              const stats = stakeholder.stats_json || stakeholder;
              const power = stats.power || 5;
              const interest = stats.interest || 0;
              const position = getPositionStyle(power, interest);
              const category = categorizeStakeholder(power, interest);
              
              return (
                <div
                  key={index}
                  className="absolute group cursor-pointer"
                  style={{
                    left: position.left,
                    top: position.top,
                    transform: 'translate(-50%, -50%)'
                  }}
                >
                  {/* Ponto */}
                  <div className={`w-3 h-3 bg-${category.color}-500 rounded-full border-2 border-white shadow-lg hover:scale-150 transition-transform`} />
                  
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-10">
                    <div className="bg-slate-950 border border-purple-500/30 rounded-lg p-3 shadow-xl min-w-48">
                      <p className="text-white font-semibold mb-1">
                        {stakeholder.name}
                      </p>
                      <p className="text-slate-400 text-xs mb-2">
                        {stakeholder.role || stakeholder.title}
                      </p>
                      <div className="text-xs space-y-1">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Poder:</span>
                          <span className="text-amber-400">{power}/10</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Interesse:</span>
                          <span className="text-purple-400">{interest}/10</span>
                        </div>
                        <div className="mt-2 pt-2 border-t border-slate-700">
                          <span className={`text-${category.color}-400 font-semibold`}>
                            {category.label}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Lista Detalhada */}
      <div className="grid md:grid-cols-2 gap-4">
        {stakeholders.map((stakeholder, index) => {
          const stats = stakeholder.stats_json || stakeholder;
          const category = categorizeStakeholder(stats.power || 5, stats.interest || 0);
          
          return (
            <Card key={index} className="bg-slate-900/50 border-purple-900/20">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-lg">
                      {stakeholder.name}
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                      {stakeholder.role || stakeholder.title}
                    </p>
                  </div>
                  <span className={`px-2 py-1 bg-${category.color}-600/20 text-${category.color}-300 text-xs rounded-lg`}>
                    {stats.archetype || 'N/A'}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Poder:</span>
                    <span className="text-amber-400 font-bold">{stats.power || 5}/10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Interesse:</span>
                    <span className="text-purple-400 font-bold">{stats.interest || 0}/10</span>
                  </div>
                  <div className="mt-3 pt-3 border-t border-slate-700">
                    <p className={`text-${category.color}-400 font-semibold text-xs`}>
                      🎯 Estratégia: {category.label}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}