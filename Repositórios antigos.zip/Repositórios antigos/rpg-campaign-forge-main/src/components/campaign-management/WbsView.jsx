import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight, Target, CheckCircle2, Circle, Download, Upload, Zap, Package, Edit } from 'lucide-react';
import EditWbsDialog from './EditWbsDialog';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';

export default function WbsView({ wbs, isOwner, campaignId }) {
  const [expandedArcs, setExpandedArcs] = useState({});
  const [expandedScenes, setExpandedScenes] = useState({});
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const toggleArc = (index) => {
    setExpandedArcs(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const toggleScene = (arcIndex, sceneIndex) => {
    const key = `${arcIndex}-${sceneIndex}`;
    setExpandedScenes(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const challengeIcons = {
    'Combate': '⚔️',
    'Social': '💬',
    'Exploração': '🗺️'
  };

  const handleSaveWbs = async (updatedWbs) => {
    const campaigns = await base44.entities.Campaign.list();
    const campaign = campaigns.find(c => c.id === campaignId);
    await base44.entities.Campaign.update(campaignId, {
      content_json: {
        ...campaign.content_json,
        wbs: updatedWbs
      }
    });
    queryClient.invalidateQueries(['campaign', campaignId]);
  };

  if (!wbs || !wbs.narrative_arcs) {
    return (
      <div className="text-center py-8 text-slate-400">
        Estrutura WBS não disponível para esta campanha
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {isOwner && (
        <div className="flex justify-end">
          <Button onClick={() => setEditDialogOpen(true)} variant="outline" className="border-purple-500/30">
            <Edit className="w-4 h-4 mr-2" />
            Editar WBS
          </Button>
        </div>
      )}
      {/* Core Objective */}
      <Card className="bg-gradient-to-br from-purple-900/30 to-slate-900/30 border-purple-500/30">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Target className="w-8 h-8 text-purple-400" />
            <div>
              <CardTitle className="text-white text-2xl">Objetivo Macro</CardTitle>
              <p className="text-slate-400 text-sm">Nível 1 - The Core</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-slate-200 text-lg leading-relaxed">
            {wbs.core_objective}
          </p>
        </CardContent>
      </Card>

      {/* Narrative Arcs */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <span className="text-purple-400">Nível 2</span> - Arcos Narrativos
        </h3>
        
        {wbs.narrative_arcs.map((arc, arcIndex) => (
          <Card key={arcIndex} className="bg-slate-900/50 border-purple-900/20">
            <CardHeader 
              className="cursor-pointer hover:bg-slate-800/30 transition-colors"
              onClick={() => toggleArc(arcIndex)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className="mt-1">
                    {expandedArcs[arcIndex] ? (
                      <ChevronDown className="w-5 h-5 text-purple-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-purple-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-white text-lg mb-2">
                      {arcIndex + 1}. {arc.name}
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                      {arc.description}
                    </p>
                  </div>
                </div>
                <span className="text-slate-500 text-sm ml-4">
                  {arc.scenes?.length || 0} cenas
                </span>
              </div>
            </CardHeader>

            {expandedArcs[arcIndex] && arc.scenes && (
              <CardContent className="pt-0">
                <div className="ml-4 space-y-2">
                  <h4 className="text-sm font-semibold text-purple-300 mb-3 flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    Nível 3 - Pacotes de Cena
                  </h4>
                  
                  {/* Árvore Visual */}
                  <div className="relative pl-6 border-l-2 border-slate-700">
                    {arc.scenes.map((scene, sceneIndex) => {
                      const isExpanded = expandedScenes[`${arcIndex}-${sceneIndex}`];
                      const isLast = sceneIndex === arc.scenes.length - 1;
                      
                      return (
                        <div key={sceneIndex} className="relative mb-3">
                          {/* Connector Line */}
                          <div className={`absolute left-0 top-0 w-6 h-6 border-b-2 ${isLast ? 'border-l-2' : 'border-l-2'} border-slate-700`} 
                               style={{ transform: 'translateX(-100%)' }} />
                          
                          {/* Scene Card */}
                          <Card className="bg-slate-950/50 border-slate-700 hover:border-purple-500/50 transition-all">
                            <CardHeader 
                              className="cursor-pointer p-3"
                              onClick={() => toggleScene(arcIndex, sceneIndex)}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-start gap-2 flex-1">
                                  {isExpanded ? (
                                    <ChevronDown className="w-4 h-4 text-purple-400 mt-0.5" />
                                  ) : (
                                    <ChevronRight className="w-4 h-4 text-purple-400 mt-0.5" />
                                  )}
                                  <div>
                                    <h5 className="text-white font-semibold text-sm">
                                      {scene.name}
                                    </h5>
                                    <span className="text-xs text-slate-500">
                                      Cena {sceneIndex + 1} • {scene.challenge_type}
                                    </span>
                                  </div>
                                </div>
                                <span className="text-lg">
                                  {challengeIcons[scene.challenge_type] || '🎲'}
                                </span>
                              </div>
                            </CardHeader>

                            {isExpanded && (
                              <CardContent className="p-3 pt-0 space-y-3">
                                {/* Input */}
                                <div className="flex gap-2 p-2 bg-green-900/10 border border-green-500/20 rounded-lg">
                                  <Download className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                                  <div className="flex-1">
                                    <span className="text-green-400 font-semibold text-xs block mb-1">
                                      INPUT
                                    </span>
                                    <span className="text-slate-300 text-sm">{scene.input}</span>
                                  </div>
                                </div>

                                {/* Processo */}
                                <div className="flex gap-2 p-2 bg-blue-900/10 border border-blue-500/20 rounded-lg">
                                  <Zap className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                                  <div className="flex-1">
                                    <span className="text-blue-400 font-semibold text-xs block mb-1">
                                      PROCESSO
                                    </span>
                                    <span className="text-slate-300 text-sm">{scene.process}</span>
                                  </div>
                                </div>

                                {/* Deliverable */}
                                <div className="flex gap-2 p-2 bg-amber-900/10 border border-amber-500/20 rounded-lg">
                                  <Upload className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                                  <div className="flex-1">
                                    <span className="text-amber-400 font-semibold text-xs block mb-1">
                                      DELIVERABLE
                                    </span>
                                    <span className="text-slate-300 text-sm">{scene.deliverable}</span>
                                  </div>
                                </div>
                              </CardContent>
                            )}
                          </Card>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}