import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, Trash2 } from 'lucide-react';

export default function EditWbsDialog({ open, onOpenChange, wbs, onSave }) {
  const [loading, setLoading] = useState(false);
  const [editedWbs, setEditedWbs] = useState(wbs || { core_objective: '', narrative_arcs: [] });

  const handleSave = async () => {
    setLoading(true);
    try {
      await onSave(editedWbs);
      onOpenChange(false);
    } catch (error) {
      console.error('Erro ao salvar WBS:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const addArc = () => {
    setEditedWbs({
      ...editedWbs,
      narrative_arcs: [
        ...editedWbs.narrative_arcs,
        { name: '', description: '', scenes: [] }
      ]
    });
  };

  const removeArc = (index) => {
    const newArcs = [...editedWbs.narrative_arcs];
    newArcs.splice(index, 1);
    setEditedWbs({ ...editedWbs, narrative_arcs: newArcs });
  };

  const updateArc = (index, field, value) => {
    const newArcs = [...editedWbs.narrative_arcs];
    newArcs[index] = { ...newArcs[index], [field]: value };
    setEditedWbs({ ...editedWbs, narrative_arcs: newArcs });
  };

  const addScene = (arcIndex) => {
    const newArcs = [...editedWbs.narrative_arcs];
    newArcs[arcIndex].scenes = [
      ...(newArcs[arcIndex].scenes || []),
      { name: '', input: '', process: '', challenge_type: 'Combate', deliverable: '' }
    ];
    setEditedWbs({ ...editedWbs, narrative_arcs: newArcs });
  };

  const removeScene = (arcIndex, sceneIndex) => {
    const newArcs = [...editedWbs.narrative_arcs];
    newArcs[arcIndex].scenes.splice(sceneIndex, 1);
    setEditedWbs({ ...editedWbs, narrative_arcs: newArcs });
  };

  const updateScene = (arcIndex, sceneIndex, field, value) => {
    const newArcs = [...editedWbs.narrative_arcs];
    newArcs[arcIndex].scenes[sceneIndex] = {
      ...newArcs[arcIndex].scenes[sceneIndex],
      [field]: value
    };
    setEditedWbs({ ...editedWbs, narrative_arcs: newArcs });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-purple-900/20 text-white max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Editar WBS da Campanha</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Core Objective */}
          <div>
            <Label className="text-white mb-2 block font-semibold">Objetivo Macro (Core Objective)</Label>
            <Textarea
              value={editedWbs.core_objective}
              onChange={(e) => setEditedWbs({ ...editedWbs, core_objective: e.target.value })}
              placeholder="O objetivo principal que a campanha busca alcançar..."
              className="min-h-[80px] bg-slate-950/50 border-slate-700 text-white"
            />
          </div>

          {/* Narrative Arcs */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-white font-semibold">Arcos Narrativos</Label>
              <Button onClick={addArc} size="sm" variant="outline" className="border-purple-500/30">
                <Plus className="w-4 h-4 mr-1" />
                Adicionar Arco
              </Button>
            </div>

            <div className="space-y-6">
              {editedWbs.narrative_arcs.map((arc, arcIndex) => (
                <div key={arcIndex} className="p-4 bg-slate-950/50 border border-slate-700 rounded-lg space-y-4">
                  <div className="flex items-start justify-between">
                    <h3 className="text-lg font-semibold text-purple-300">Arco {arcIndex + 1}</h3>
                    <Button
                      onClick={() => removeArc(arcIndex)}
                      size="sm"
                      variant="ghost"
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div>
                    <Label className="text-slate-300 text-sm mb-1 block">Nome do Arco</Label>
                    <Input
                      value={arc.name}
                      onChange={(e) => updateArc(arcIndex, 'name', e.target.value)}
                      placeholder="Ex: A Ascensão das Sombras"
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300 text-sm mb-1 block">Descrição</Label>
                    <Textarea
                      value={arc.description}
                      onChange={(e) => updateArc(arcIndex, 'description', e.target.value)}
                      placeholder="Descreva o arco narrativo em detalhes..."
                      className="min-h-[100px] bg-slate-900 border-slate-600 text-white"
                    />
                  </div>

                  {/* Scenes */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label className="text-slate-300 text-sm">Cenas</Label>
                      <Button
                        onClick={() => addScene(arcIndex)}
                        size="sm"
                        variant="outline"
                        className="border-slate-600 text-xs"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Adicionar Cena
                      </Button>
                    </div>

                    <div className="space-y-3">
                      {(arc.scenes || []).map((scene, sceneIndex) => (
                        <div key={sceneIndex} className="p-3 bg-slate-900 border border-slate-600 rounded space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-400">Cena {sceneIndex + 1}</span>
                            <Button
                              onClick={() => removeScene(arcIndex, sceneIndex)}
                              size="sm"
                              variant="ghost"
                              className="text-red-400 h-6 w-6 p-0"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>

                          <Input
                            value={scene.name}
                            onChange={(e) => updateScene(arcIndex, sceneIndex, 'name', e.target.value)}
                            placeholder="Nome da cena"
                            className="bg-slate-950 border-slate-600 text-white text-sm"
                          />

                          <Select
                            value={scene.challenge_type}
                            onValueChange={(value) => updateScene(arcIndex, sceneIndex, 'challenge_type', value)}
                          >
                            <SelectTrigger className="bg-slate-950 border-slate-600 text-white text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Combate">⚔️ Combate</SelectItem>
                              <SelectItem value="Social">💬 Social</SelectItem>
                              <SelectItem value="Exploração">🗺️ Exploração</SelectItem>
                            </SelectContent>
                          </Select>

                          <Textarea
                            value={scene.input}
                            onChange={(e) => updateScene(arcIndex, sceneIndex, 'input', e.target.value)}
                            placeholder="Input (pré-requisitos)"
                            className="min-h-[60px] bg-slate-950 border-slate-600 text-white text-sm"
                          />

                          <Textarea
                            value={scene.process}
                            onChange={(e) => updateScene(arcIndex, sceneIndex, 'process', e.target.value)}
                            placeholder="Processo (desafio central)"
                            className="min-h-[80px] bg-slate-950 border-slate-600 text-white text-sm"
                          />

                          <Textarea
                            value={scene.deliverable}
                            onChange={(e) => updateScene(arcIndex, sceneIndex, 'deliverable', e.target.value)}
                            placeholder="Deliverable (recompensa)"
                            className="min-h-[60px] bg-slate-950 border-slate-600 text-white text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-700">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="border-slate-700">
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={loading} className="bg-purple-600 hover:bg-purple-700">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                'Salvar WBS'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}