import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronRight, Target, Users, AlertTriangle, BookOpen, CheckCircle2, Circle } from 'lucide-react';

export default function ArcDisplay({ arc, index }) {
  const [openActs, setOpenActs] = useState({});
  const [openScenes, setOpenScenes] = useState({});

  const toggleAct = (actIndex) => {
    setOpenActs(prev => ({ ...prev, [actIndex]: !prev[actIndex] }));
  };

  const toggleScene = (actIndex, sceneIndex) => {
    const key = `${actIndex}-${sceneIndex}`;
    setOpenScenes(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <Card className="bg-slate-900/50 backdrop-blur-xl border-purple-900/20">
      <CardHeader>
        <CardTitle className="text-2xl text-white flex items-center gap-3">
          <span className="flex items-center justify-center w-10 h-10 rounded-full bg-purple-600/20 text-purple-300 font-bold border border-purple-500/30">
            {index + 1}
          </span>
          {arc.name}
        </CardTitle>
        
        {arc.description && (
          <p className="text-slate-300 mt-3 leading-relaxed">
            {arc.description}
          </p>
        )}

        <div className="grid md:grid-cols-2 gap-4 mt-4">
          {arc.arc_objective && (
            <div className="p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg">
              <p className="text-blue-300 text-sm font-semibold mb-1">🎯 Objetivo do Arco</p>
              <p className="text-slate-300 text-sm">{arc.arc_objective}</p>
            </div>
          )}
          
          {arc.arc_villain && (
            <div className="p-3 bg-red-900/20 border border-red-500/30 rounded-lg">
              <p className="text-red-300 text-sm font-semibold mb-1">👹 Antagonista</p>
              <p className="text-slate-300 text-sm">{arc.arc_villain}</p>
            </div>
          )}
        </div>

        {arc.world_change && (
          <div className="p-3 bg-amber-900/20 border border-amber-500/30 rounded-lg mt-4">
            <p className="text-amber-300 text-sm font-semibold mb-1">🌍 Mudança no Mundo</p>
            <p className="text-slate-300 text-sm">{arc.world_change}</p>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        {arc.acts && arc.acts.map((act, actIndex) => (
          <Card key={actIndex} className="bg-slate-950/50 border-slate-700">
            <Collapsible open={openActs[actIndex]} onOpenChange={() => toggleAct(actIndex)}>
              <CollapsibleTrigger className="w-full">
                <CardHeader className="cursor-pointer hover:bg-slate-800/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {openActs[actIndex] ? (
                        <ChevronDown className="w-5 h-5 text-purple-400" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-purple-400" />
                      )}
                      <span className="text-lg font-bold text-white">
                        Ato {actIndex + 1}: {act.title}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-1 bg-purple-600/20 text-purple-300 rounded">
                        {act.scenes?.length || 0} cenas
                      </span>
                      {act.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-green-400" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-600" />
                      )}
                    </div>
                  </div>
                  
                  {act.description && (
                    <p className="text-slate-400 text-sm text-left mt-2">
                      {act.description}
                    </p>
                  )}
                </CardHeader>
              </CollapsibleTrigger>

              <CollapsibleContent>
                <CardContent className="space-y-4 pt-0">
                  {act.objectives && act.objectives.length > 0 && (
                    <div className="p-3 bg-blue-900/10 border border-blue-500/20 rounded-lg">
                      <p className="text-blue-300 font-semibold mb-2 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Objetivos
                      </p>
                      <ul className="space-y-1 text-slate-300 text-sm">
                        {act.objectives.map((obj, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-blue-400 mt-1">•</span>
                            <span>{obj}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {act.twist && (
                    <div className="p-3 bg-amber-900/10 border border-amber-500/20 rounded-lg">
                      <p className="text-amber-300 font-semibold mb-1 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        Reviravolta
                      </p>
                      <p className="text-slate-300 text-sm">{act.twist}</p>
                    </div>
                  )}

                  {act.npcs_involved && act.npcs_involved.length > 0 && (
                    <div className="p-3 bg-purple-900/10 border border-purple-500/20 rounded-lg">
                      <p className="text-purple-300 font-semibold mb-2 flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        NPCs Envolvidos
                      </p>
                      <p className="text-slate-300 text-sm">{act.npcs_involved.join(', ')}</p>
                    </div>
                  )}

                  {/* Cenas do Ato */}
                  {act.scenes && act.scenes.length > 0 && (
                    <div className="space-y-3 mt-4">
                      <h4 className="text-white font-semibold">Cenas:</h4>
                      {act.scenes.map((scene, sceneIndex) => (
                        <Card key={sceneIndex} className="bg-slate-900/50 border-slate-600">
                          <Collapsible 
                            open={openScenes[`${actIndex}-${sceneIndex}`]} 
                            onOpenChange={() => toggleScene(actIndex, sceneIndex)}
                          >
                            <CollapsibleTrigger className="w-full">
                              <CardHeader className="cursor-pointer hover:bg-slate-800/30 transition-colors py-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    {openScenes[`${actIndex}-${sceneIndex}`] ? (
                                      <ChevronDown className="w-4 h-4 text-purple-400" />
                                    ) : (
                                      <ChevronRight className="w-4 h-4 text-purple-400" />
                                    )}
                                    <span className="text-white font-medium">
                                      Cena {sceneIndex + 1}: {scene.scene_name}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs px-2 py-1 bg-slate-700 text-slate-300 rounded">
                                      {scene.scene_type}
                                    </span>
                                    {scene.completed ? (
                                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                                    ) : (
                                      <Circle className="w-4 h-4 text-slate-600" />
                                    )}
                                  </div>
                                </div>
                              </CardHeader>
                            </CollapsibleTrigger>

                            <CollapsibleContent>
                              <CardContent className="space-y-3 text-sm pt-0">
                                {scene.trigger && (
                                  <div>
                                    <p className="text-slate-400 font-semibold mb-1">Gatilho:</p>
                                    <p className="text-slate-300">{scene.trigger}</p>
                                  </div>
                                )}

                                {scene.read_aloud && (
                                  <div className="p-3 bg-purple-900/10 border border-purple-500/20 rounded">
                                    <p className="text-purple-300 font-semibold mb-2 flex items-center gap-2">
                                      <BookOpen className="w-4 h-4" />
                                      Leia para os Jogadores:
                                    </p>
                                    <p className="text-slate-200 italic leading-relaxed">{scene.read_aloud}</p>
                                  </div>
                                )}

                                {scene.hidden_reality && (
                                  <div>
                                    <p className="text-red-400 font-semibold mb-1">🔒 Realidade Oculta:</p>
                                    <p className="text-slate-300">{scene.hidden_reality}</p>
                                  </div>
                                )}

                                {scene.objective && (
                                  <div>
                                    <p className="text-blue-400 font-semibold mb-1">🎯 Objetivo:</p>
                                    <p className="text-slate-300">{scene.objective}</p>
                                  </div>
                                )}

                                {scene.secrets_and_clues && scene.secrets_and_clues.length > 0 && (
                                  <div>
                                    <p className="text-amber-400 font-semibold mb-2">🔍 Pistas e Segredos:</p>
                                    <div className="space-y-2">
                                      {scene.secrets_and_clues.map((secret, i) => (
                                        <div key={i} className="p-2 bg-amber-900/10 border border-amber-500/20 rounded">
                                          <p className="text-slate-200">{secret.clue}</p>
                                          <p className="text-slate-400 text-xs mt-1">Como encontrar: {secret.how_to_find}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {scene.suggested_checks && scene.suggested_checks.length > 0 && (
                                  <div>
                                    <p className="text-green-400 font-semibold mb-2">🎲 Testes Sugeridos:</p>
                                    <div className="space-y-2">
                                      {scene.suggested_checks.map((check, i) => (
                                        <div key={i} className="p-2 bg-green-900/10 border border-green-500/20 rounded">
                                          <p className="text-slate-200 font-medium">{check.skill} (CD {check.dc})</p>
                                          <p className="text-green-300 text-xs">✓ Sucesso: {check.on_success}</p>
                                          <p className="text-red-300 text-xs">✗ Falha: {check.on_failure}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {scene.opposition_active && (
                                  <div>
                                    <p className="text-red-400 font-semibold mb-1">⚔️ Oposição Ativa:</p>
                                    <p className="text-slate-300">{scene.opposition_active}</p>
                                  </div>
                                )}

                                {scene.opposition_passive && (
                                  <div>
                                    <p className="text-orange-400 font-semibold mb-1">🚧 Oposição Passiva:</p>
                                    <p className="text-slate-300">{scene.opposition_passive}</p>
                                  </div>
                                )}

                                {scene.outcomes && scene.outcomes.length > 0 && (
                                  <div>
                                    <p className="text-slate-400 font-semibold mb-1">Possíveis Desfechos:</p>
                                    <ul className="space-y-1">
                                      {scene.outcomes.map((outcome, i) => (
                                        <li key={i} className="text-slate-300 flex items-start gap-2">
                                          <span className="text-purple-400">•</span>
                                          {outcome}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {scene.rewards && (
                                  <div className="p-2 bg-yellow-900/10 border border-yellow-500/20 rounded">
                                    <p className="text-yellow-400 font-semibold mb-1">💰 Recompensas:</p>
                                    <p className="text-slate-300">{scene.rewards}</p>
                                  </div>
                                )}
                              </CardContent>
                            </CollapsibleContent>
                          </Collapsible>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        ))}
      </CardContent>
    </Card>
  );
}