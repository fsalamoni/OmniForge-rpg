import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ArcGenerator({ campaignId, description, answers5W2H, systemRpg, setting, onArcGenerated }) {
  const [arcName, setArcName] = useState('');
  const [missionType, setMissionType] = useState('Investigação');
  const [numActs, setNumActs] = useState(3);
  const [scenesPerAct, setScenesPerAct] = useState(2);
  const [customInstructions, setCustomInstructions] = useState('');
  const [generating, setGenerating] = useState(false);

  const missionTypes = [
    'Investigação',
    'Exploração',
    'Roubo',
    'Assassinato',
    'Resgate',
    'Diplomacia',
    'Infiltração',
    'Defesa',
    'Conquista',
    'Mistério',
    'Sobrevivência',
    'Caça',
    'Escolta'
  ];

  const handleGenerate = async () => {
    if (!arcName.trim()) {
      alert('Por favor, defina um nome para o arco');
      return;
    }

    setGenerating(true);
    try {
      console.log('🤖 Iniciando geração do arco com IA...');
      console.log('📊 Parâmetros:', { arcName, missionType, numActs, scenesPerAct });
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um designer profissional de aventuras de RPG. Crie um ARCO NARRATIVO completo para ${systemRpg} em ${setting}.

NOME DO ARCO: ${arcName}
TIPO DE MISSÃO: ${missionType}
ESTRUTURA: ${numActs} ATOS com ${scenesPerAct} CENAS POR ATO

CONTEXTO DA CAMPANHA:
${description.substring(0, 1000)}

${customInstructions ? `INSTRUÇÕES ESPECÍFICAS:\n${customInstructions}\n\n` : ''}

ESTRUTURA DO ARCO:

1. METADADOS:
- name: "${arcName}"
- arc_objective: Objetivo principal (1 frase)
- world_change: Mudança no mundo (2 frases)
- arc_villain: Antagonista principal (2 frases)
- description: Resumo do arco (4-5 frases)

2. ATOS (CRIAR ${numActs} ATOS):
Cada ato deve ter:
- title: Nome do ato
- act_function: "setup", "rising_action", "climax" ou "falling_action"
- description: O que acontece (4-5 frases)
- objectives: 3 objetivos dos jogadores
- twist: Reviravolta (se aplicável)
- npcs_involved: NPCs importantes
- scenes: Array com ${scenesPerAct} cenas

3. CENAS (${scenesPerAct} por ato):
Cada cena deve ter:
- scene_name: Nome da cena
- scene_type: "Social", "Combate", "Exploração", "Puzzle" ou "Híbrido"
- trigger: O que inicia (2 frases)
- read_aloud: Texto para ler aos jogadores (3-4 frases sensoriais)
- hidden_reality: O que está oculto (2-3 frases)
- secrets_and_clues: 2-3 pistas descobríveis
- objective: Objetivo da cena
- opposition_passive: Obstáculos (se houver)
- opposition_active: Inimigos (se houver)
- suggested_checks: 2-3 testes sugeridos
- outcomes: 2-3 possíveis finais
- exits: Para onde leva
- rewards: Recompensas

CRÍTICO: Retorne um objeto JSON válido com:
- name (string)
- arc_objective (string)
- world_change (string)
- arc_villain (string)
- description (string)
- acts (array com ${numActs} objetos, cada um com scenes array de ${scenesPerAct} itens)

Seja detalhado e criativo!`,
        response_json_schema: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            arc_objective: { type: 'string' },
            world_change: { type: 'string' },
            arc_villain: { type: 'string' },
            description: { type: 'string' },
            acts: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  act_function: { type: 'string' },
                  description: { type: 'string' },
                  objectives: { type: 'array', items: { type: 'string' } },
                  twist: { type: 'string' },
                  npcs_involved: { type: 'array', items: { type: 'string' } },
                  scenes: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        scene_name: { type: 'string' },
                        scene_type: { type: 'string' },
                        trigger: { type: 'string' },
                        read_aloud: { type: 'string' },
                        hidden_reality: { type: 'string' },
                        secrets_and_clues: { 
                          type: 'array', 
                          items: { 
                            type: 'object',
                            properties: {
                              clue: { type: 'string' },
                              how_to_find: { type: 'string' }
                            }
                          } 
                        },
                        objective: { type: 'string' },
                        opposition_passive: { type: 'string' },
                        opposition_active: { type: 'string' },
                        suggested_checks: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              skill: { type: 'string' },
                              dc: { type: 'string' },
                              on_success: { type: 'string' },
                              on_failure: { type: 'string' }
                            }
                          }
                        },
                        outcomes: { type: 'array', items: { type: 'string' } },
                        exits: { type: 'string' },
                        rewards: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          },
          required: ['name', 'acts']
        }
      });

      console.log('✅ Resposta da IA recebida');
      console.log('📦 Estrutura recebida:', {
        temName: !!result?.name,
        temActs: !!result?.acts,
        numAtos: result?.acts?.length,
        acts: result?.acts?.map((act, i) => ({
          index: i,
          title: act?.title,
          numScenes: act?.scenes?.length
        }))
      });
      
      // Validar resultado antes de enviar
      if (!result || !result.name) {
        throw new Error('IA retornou um arco sem nome');
      }
      
      if (!result.acts || !Array.isArray(result.acts) || result.acts.length === 0) {
        throw new Error('IA não criou nenhum ato para o arco');
      }

      await onArcGenerated(result);
      
      // Resetar form
      setArcName('');
      setCustomInstructions('');
      setMissionType('Investigação');
      setNumActs(3);
      setScenesPerAct(2);
    } catch (error) {
      console.error('Erro ao gerar arco:', error);
      alert('Erro ao gerar arco: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Card className="bg-slate-900/50 backdrop-blur-xl border-purple-900/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Sparkles className="w-6 h-6 text-purple-400" />
          Criar Novo Arco Narrativo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-slate-300">Nome do Arco *</Label>
          <Input
            value={arcName}
            onChange={(e) => setArcName(e.target.value)}
            placeholder="Ex: O Segredo das Ruínas Antigas"
            className="bg-slate-950/50 border-slate-700 text-white mt-2"
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label className="text-slate-300">Tipo de Missão</Label>
            <Select value={missionType} onValueChange={setMissionType}>
              <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {missionTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-slate-300">Número de Atos</Label>
            <Input
              type="number"
              min="2"
              max="6"
              value={numActs}
              onChange={(e) => setNumActs(parseInt(e.target.value))}
              className="bg-slate-950/50 border-slate-700 text-white mt-2"
            />
          </div>

          <div>
            <Label className="text-slate-300">Cenas por Ato</Label>
            <Input
              type="number"
              min="1"
              max="5"
              value={scenesPerAct}
              onChange={(e) => setScenesPerAct(parseInt(e.target.value))}
              className="bg-slate-950/50 border-slate-700 text-white mt-2"
            />
          </div>
        </div>

        <div>
          <Label className="text-slate-300">Instruções Específicas (Opcional)</Label>
          <Textarea
            value={customInstructions}
            onChange={(e) => setCustomInstructions(e.target.value)}
            placeholder="Ex: Incluir elementos de horror, focar em dilemas morais..."
            className="bg-slate-950/50 border-slate-700 text-white mt-2 min-h-[100px]"
          />
        </div>

        <Button
          onClick={handleGenerate}
          disabled={generating || !arcName.trim()}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600"
        >
          {generating ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Gerando arco...
            </>
          ) : (
            <>
              <BookOpen className="w-5 h-5 mr-2" />
              Gerar Arco: {arcName || 'Defina um nome'}
            </>
          )}
        </Button>

        <p className="text-xs text-slate-500 text-center">
          Será gerado: {numActs} atos × {scenesPerAct} cenas = {numActs * scenesPerAct} cenas totais
        </p>
      </CardContent>
    </Card>
  );
}