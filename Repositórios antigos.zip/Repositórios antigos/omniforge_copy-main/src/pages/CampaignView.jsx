import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import NpcCard from '../components/campaign-view/NpcCard';
import GenerateNpcDialog from '../components/campaign-view/GenerateNpcDialog';
import EditableSection from '../components/campaign-view/EditableSection';
import EncounterCard from '../components/campaign-view/EncounterCard';
import PlotHooksList from '../components/campaign-view/PlotHooksList';
import ArcGenerator from '../components/campaign-view/ArcGenerator';
import ArcDisplay from '../components/campaign-view/ArcDisplay';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowLeft, 
  BookOpen, 
  Users, 
  StickyNote,
  Settings,
  Globe,
  Lock,
  Loader2,
  Share2,
  Sparkles,
  Filter
} from 'lucide-react';

export default function CampaignView() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const campaignId = searchParams.get('id');
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [masterNotes, setMasterNotes] = useState('');
  const [notesChanged, setNotesChanged] = useState(false);
  const [npcFilter, setNpcFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('narrative');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        await base44.auth.redirectToLogin(createPageUrl('CampaignView') + '?id=' + campaignId);
      }
    };
    loadUser();
  }, []);

  const { data: campaign, isLoading, refetch } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: async () => {
      const campaigns = await base44.entities.Campaign.list();
      const camp = campaigns.find(c => c.id === campaignId);
      if (camp) {
        setMasterNotes(camp.master_notes || '');
      }
      return camp;
    },
    enabled: !!campaignId
  });

  const { data: npcs = [] } = useQuery({
    queryKey: ['npcs', campaignId],
    queryFn: () => base44.entities.NpcCreature.filter({ campaign_id: campaignId }),
    enabled: !!campaignId
  });

  const updateNotesMutation = useMutation({
    mutationFn: () => base44.entities.Campaign.update(campaignId, { master_notes: masterNotes }),
    onSuccess: () => {
      queryClient.invalidateQueries(['campaign', campaignId]);
      setNotesChanged(false);
    }
  });

  const togglePublicMutation = useMutation({
    mutationFn: () => base44.entities.Campaign.update(campaignId, { is_public: !campaign.is_public }),
    onSuccess: () => {
      queryClient.invalidateQueries(['campaign', campaignId]);
    }
  });

  const updateContentMutation = useMutation({
    mutationFn: (newContent) => base44.entities.Campaign.update(campaignId, { content_json: newContent }),
    onSuccess: () => {
      queryClient.invalidateQueries(['campaign', campaignId]);
    }
  });

  const handleUpdateSummary = async (newSummary) => {
    const updatedContent = { ...content, adventure_summary: newSummary };
    await updateContentMutation.mutateAsync(updatedContent);
  };

  const handleUpdateHooks = async (newHooks) => {
    const updatedContent = { ...content, plot_hooks: newHooks };
    await updateContentMutation.mutateAsync(updatedContent);
  };

  const handleArcGenerated = async (newArc) => {
    try {
      console.log('🎬 Salvando arco gerado:', newArc);
      
      // Validar estrutura do arco
      if (!newArc || typeof newArc !== 'object') {
        throw new Error('Arco inválido: estrutura vazia ou incorreta');
      }
      
      if (!newArc.name) {
        throw new Error('Arco inválido: nome não definido');
      }
      
      if (!Array.isArray(newArc.acts) || newArc.acts.length === 0) {
        throw new Error('Arco inválido: nenhum ato foi criado');
      }
      
      // Buscar dados atualizados da campanha
      const campaigns = await base44.entities.Campaign.list();
      const currentCampaign = campaigns.find(c => c.id === campaignId);
      
      if (!currentCampaign) {
        throw new Error('Campanha não encontrada');
      }
      
      const currentContent = currentCampaign.content_json || {};
      const currentArcs = currentContent.narrative_arcs || [];
      
      // Adicionar completed = false em todos os atos e cenas
      const arcWithCompletion = {
        ...newArc,
        acts: (newArc.acts || []).map(act => ({
          ...act,
          completed: false,
          scenes: (act.scenes || []).map(scene => ({
            ...scene,
            completed: false
          }))
        }))
      };
      
      const updatedContent = {
        ...currentContent,
        narrative_arcs: [...currentArcs, arcWithCompletion]
      };
      
      console.log('💾 Salvando content_json com', updatedContent.narrative_arcs.length, 'arcos');
      
      await base44.entities.Campaign.update(campaignId, { 
        content_json: updatedContent 
      });
      
      console.log('✅ Arco salvo com sucesso!');
      
      // Forçar refetch dos dados
      await queryClient.invalidateQueries(['campaign', campaignId]);
      await refetch();
      
      const totalScenes = arcWithCompletion.acts.reduce((sum, act) => sum + (act.scenes?.length || 0), 0);
      alert(`✅ Arco "${arcWithCompletion.name}" salvo com sucesso!\n\n${arcWithCompletion.acts.length} atos criados\n${totalScenes} cenas criadas`);
      
      setActiveTab('arcs');
    } catch (error) {
      console.error('❌ Erro ao salvar arco:', error);
      alert('ERRO ao salvar arco: ' + error.message);
    }
  };

  if (!campaignId) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400">ID de campanha não fornecido</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="text-center py-16">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
        <p className="text-slate-400">Carregando campanha...</p>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400 mb-4">Campanha não encontrada</p>
        <Button onClick={() => navigate(createPageUrl('MyCampaigns'))}>
          Voltar para Minhas Campanhas
        </Button>
      </div>
    );
  }

  const content = campaign.content_json || {};
  const isOwner = campaign.created_by === user?.email;

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <button
          onClick={() => navigate(createPageUrl('MyCampaigns'))}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar para Campanhas
        </button>

        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <Sparkles className="w-8 h-8 text-purple-400" />
              <h1 className="text-4xl font-bold text-white">
                {campaign.title}
              </h1>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="px-3 py-1 bg-purple-600/20 text-purple-300 text-sm font-medium rounded-lg border border-purple-500/30">
                {campaign.system_rpg}
              </span>
              <span className="px-3 py-1 bg-amber-600/20 text-amber-300 text-sm font-medium rounded-lg border border-amber-500/30">
                {campaign.setting}
              </span>
              <span className="px-3 py-1 bg-blue-600/20 text-blue-300 text-sm font-medium rounded-lg border border-blue-500/30">
                {campaign.duration_type}
              </span>
              <span className="px-3 py-1 bg-slate-600/20 text-slate-300 text-sm font-medium rounded-lg border border-slate-500/30">
                {campaign.players_count} jogadores
              </span>
            </div>

            <p className="text-slate-400">
              Nível de criatividade: <span className="text-purple-400 font-semibold">{campaign.creativity_level}/5</span>
            </p>
          </div>

          {isOwner && (
            <div className="flex gap-3">
              <Button
                onClick={() => navigate(createPageUrl('Generator') + '?id=' + campaign.id)}
                variant="outline"
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Editar Informações
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-slate-900/50 border border-purple-900/20 p-1">
          <TabsTrigger value="narrative" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
            <BookOpen className="w-4 h-4 mr-2" />
            Narrativa
          </TabsTrigger>
          <TabsTrigger value="arcs" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
            <Sparkles className="w-4 h-4 mr-2" />
            Arcos Narrativos
          </TabsTrigger>
          <TabsTrigger value="npcs" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
            <Users className="w-4 h-4 mr-2" />
            NPCs e Monstros
          </TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
            <StickyNote className="w-4 h-4 mr-2" />
            Notas do Mestre
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
            <Settings className="w-4 h-4 mr-2" />
            Configurações
          </TabsTrigger>
        </TabsList>

        {/* Tab: Narrativa */}
        <TabsContent value="narrative" className="space-y-6">
          {/* Resumo da Aventura - Editável */}
          {content.adventure_summary && isOwner && (
            <EditableSection
              title="Resumo da Aventura"
              content={content.adventure_summary}
              onSave={handleUpdateSummary}
              icon={BookOpen}
            />
          )}

          {content.adventure_summary && !isOwner && (
            <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-purple-400" />
                Resumo da Aventura
              </h2>
              <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                {content.adventure_summary}
              </p>
            </div>
          )}

          {/* Ganchos de Aventura */}
          {content.plot_hooks && content.plot_hooks.length > 0 && (
            <PlotHooksList 
              hooks={content.plot_hooks} 
              onSave={handleUpdateHooks}
              isOwner={isOwner}
            />
          )}

          {/* Encontros */}
          {content.encounters && content.encounters.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">
                  Encontros Balanceados
                </h2>
                <span className="text-slate-400">
                  {content.encounters.length} {content.encounters.length === 1 ? 'encontro' : 'encontros'}
                </span>
              </div>
              {content.encounters.map((encounter, index) => (
                <EncounterCard key={index} encounter={encounter} index={index} />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Tab: Arcos Narrativos */}
        <TabsContent value="arcs" className="space-y-6">
          {isOwner && (
            <ArcGenerator
              campaignId={campaignId}
              description={content.adventure_summary || ''}
              answers5W2H={campaign.content_json?.answers_5w2h || ''}
              systemRpg={campaign.system_rpg}
              setting={campaign.setting}
              onArcGenerated={handleArcGenerated}
            />
          )}

          {content.narrative_arcs && content.narrative_arcs.length > 0 ? (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">
                Arcos Criados ({content.narrative_arcs.length})
              </h2>
              {content.narrative_arcs.map((arc, index) => (
                <ArcDisplay key={index} arc={arc} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
              <Sparkles className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400 mb-2">Nenhum arco narrativo criado ainda</p>
              <p className="text-slate-500 text-sm">Use o gerador acima para criar seu primeiro arco</p>
            </div>
          )}
        </TabsContent>

        {/* Tab: NPCs */}
        <TabsContent value="npcs">
          <div className="space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">
                  Personagens e Criaturas
                </h2>
                <span className="text-slate-400">
                  {npcs.filter(n => npcFilter === 'all' || n.type === npcFilter).length} {' '}
                  {npcs.filter(n => npcFilter === 'all' || n.type === npcFilter).length === 1 ? 'personagem' : 'personagens'}
                </span>
              </div>
              
              <div className="flex gap-3">
                <Select value={npcFilter} onValueChange={setNpcFilter}>
                  <SelectTrigger className="w-40 bg-slate-900/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="NPC">NPCs</SelectItem>
                    <SelectItem value="Ally">Aliados</SelectItem>
                    <SelectItem value="Villain">Vilões</SelectItem>
                    <SelectItem value="Monster">Monstros</SelectItem>
                  </SelectContent>
                </Select>
                
                {isOwner && (
                  <GenerateNpcDialog
                    campaignId={campaignId}
                    systemRpg={campaign.system_rpg}
                    setting={campaign.setting}
                    onNpcCreated={() => queryClient.invalidateQueries(['npcs', campaignId])}
                  />
                )}
              </div>
            </div>

            {npcs.length === 0 ? (
              <div className="text-center py-16 bg-slate-900/30 backdrop-blur-xl border border-slate-800 rounded-2xl">
                <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">Nenhum NPC ou criatura gerado ainda</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {npcs
                  .filter(npc => npcFilter === 'all' || npc.type === npcFilter)
                  .map((npc) => (
                    <NpcCard key={npc.id} npc={npc} />
                  ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab: Notas do Mestre */}
        <TabsContent value="notes">
          <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl">
            <h2 className="text-2xl font-bold text-white mb-4">
              Notas do Mestre
            </h2>
            <p className="text-slate-400 mb-4">
              Use este espaço para adicionar suas próprias anotações, ideias e modificações.
            </p>
            
            <Textarea
              value={masterNotes}
              onChange={(e) => {
                setMasterNotes(e.target.value);
                setNotesChanged(true);
              }}
              placeholder="Adicione suas notas aqui..."
              className="min-h-[300px] bg-slate-950/50 border-slate-700 text-white"
              disabled={!isOwner}
            />

            {isOwner && notesChanged && (
              <div className="flex justify-end mt-4">
                <Button
                  onClick={() => updateNotesMutation.mutate()}
                  disabled={updateNotesMutation.isLoading}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {updateNotesMutation.isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    'Salvar Notas'
                  )}
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab: Configurações */}
        <TabsContent value="settings">
          <div className="p-6 bg-slate-900/50 backdrop-blur-xl border border-purple-900/20 rounded-2xl space-y-6">
            <h2 className="text-2xl font-bold text-white mb-4">
              Configurações da Campanha
            </h2>

            {isOwner ? (
              <>
                {/* Visibilidade */}
                <div className="p-6 bg-slate-950/50 border border-slate-700 rounded-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {campaign.is_public ? (
                          <Globe className="w-5 h-5 text-green-400" />
                        ) : (
                          <Lock className="w-5 h-5 text-slate-500" />
                        )}
                        <h3 className="text-lg font-semibold text-white">
                          {campaign.is_public ? 'Campanha Pública' : 'Campanha Privada'}
                        </h3>
                      </div>
                      <p className="text-slate-400 text-sm">
                        {campaign.is_public 
                          ? 'Esta campanha está visível na biblioteca pública e pode ser clonada por outros usuários.'
                          : 'Esta campanha é privada e apenas você pode vê-la.'
                        }
                      </p>
                    </div>
                    <Button
                      onClick={() => togglePublicMutation.mutate()}
                      disabled={togglePublicMutation.isLoading}
                      variant="outline"
                      className={campaign.is_public 
                        ? 'border-red-900/50 text-red-400 hover:bg-red-900/20'
                        : 'border-green-900/50 text-green-400 hover:bg-green-900/20'
                      }
                    >
                      {togglePublicMutation.isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          {campaign.is_public ? 'Tornar Privada' : 'Tornar Pública'}
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {/* Estatísticas */}
                {campaign.is_public && campaign.clone_count > 0 && (
                  <div className="p-6 bg-purple-900/10 border border-purple-500/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Share2 className="w-5 h-5 text-purple-400" />
                      <h3 className="text-lg font-semibold text-white">
                        Estatísticas
                      </h3>
                    </div>
                    <p className="text-slate-300">
                      Esta campanha foi clonada <span className="text-purple-400 font-bold">{campaign.clone_count}</span> {campaign.clone_count === 1 ? 'vez' : 'vezes'}
                    </p>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-8 text-slate-400">
                Apenas o criador da campanha pode modificar configurações.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}