import CampaignView from './pages/CampaignView';
import Dashboard from './pages/Dashboard';
import Generator from './pages/Generator';
import Help from './pages/Help';
import Home from './pages/Home';
import Library from './pages/Library';
import MyCampaigns from './pages/MyCampaigns';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import __Layout from './Layout.jsx';


export const PAGES = {
    "CampaignView": CampaignView,
    "Dashboard": Dashboard,
    "Generator": Generator,
    "Help": Help,
    "Home": Home,
    "Library": Library,
    "MyCampaigns": MyCampaigns,
    "Profile": Profile,
    "Settings": Settings,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};